<?php
/**
 * Single product card partial.
 *
 * @var array<string,mixed> $card_data
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$card_id     = isset( $card_data['id'] ) ? absint( $card_data['id'] ) : wp_rand( 10, 9999 );
$product_url = get_permalink( $card_id );
?>
<article
	class="zzz-product-card"
	data-zzz-card
	data-authority-level="<?php echo esc_attr( (string) ( isset( $card_data['inter_knot_level_raw'] ) ? (int) $card_data['inter_knot_level_raw'] : 0 ) ); ?>"
	data-server="<?php echo esc_attr( isset( $card_data['server_raw'] ) ? (string) $card_data['server_raw'] : '' ); ?>"
	data-price="<?php echo esc_attr( (string) ( isset( $card_data['price_raw'] ) ? (float) $card_data['price_raw'] : 0 ) ); ?>"
	data-created-at="<?php echo esc_attr( (string) ( isset( $card_data['created_at'] ) ? (int) $card_data['created_at'] : 0 ) ); ?>"
	data-characters="<?php echo esc_attr( wp_json_encode( isset( $card_data['characters_filter_items'] ) ? $card_data['characters_filter_items'] : array() ) ); ?>"
	data-discs="<?php echo esc_attr( wp_json_encode( isset( $card_data['discs_filter_items'] ) ? $card_data['discs_filter_items'] : array() ) ); ?>"
>
	<?php
	$seller_profile_url = ! empty( $card_data['seller_profile_url'] ) ? (string) $card_data['seller_profile_url'] : '';
	$seller_user_id     = ! empty( $card_data['seller_user_id'] ) ? absint( $card_data['seller_user_id'] ) : 0;
	$can_start_chat     = is_user_logged_in() && $seller_user_id > 0 && get_current_user_id() !== $seller_user_id;
	?>
	<div class="zzz-product-card__seller-row">
		<?php if ( '' !== $seller_profile_url ) : ?>
			<a class="zzz-product-card__seller-link" href="<?php echo esc_url( $seller_profile_url ); ?>" target="_blank" rel="noopener noreferrer">
		<?php endif; ?>
		<div class="zzz-product-card__seller">
		<?php if ( ! empty( $card_data['seller_avatar'] ) ) : ?>
			<img class="zzz-product-card__seller-avatar" src="<?php echo esc_url( (string) $card_data['seller_avatar'] ); ?>" alt="<?php echo esc_attr( (string) $card_data['seller_name'] ); ?>" loading="lazy" />
		<?php endif; ?>
		<div class="zzz-product-card__seller-meta">
			<span class="zzz-product-card__seller-name"><?php echo esc_html( (string) $card_data['seller_name'] ); ?></span>
			<?php if ( ! empty( $card_data['seller_verified_badge'] ) ) : ?>
				<?php echo $card_data['seller_verified_badge']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php endif; ?>
		</div>
		</div>
		<?php if ( '' !== $seller_profile_url ) : ?>
			</a>
		<?php endif; ?>

		<?php if ( $can_start_chat ) : ?>
			<button type="button" class="scp-chat-launch scp-chat-launch-profile zzz-chat-launch" data-target-user="<?php echo esc_attr( (string) $seller_user_id ); ?>" data-target-name="<?php echo esc_attr( (string) $card_data['seller_name'] ); ?>">💬 <?php esc_html_e( 'چت با فروشنده', 'zenless-zone-zero-edd-account-form' ); ?></button>
		<?php endif; ?>
	</div>

	<div class="zzz-product-card__headline">
		<a class="zzz-product-card__view-btn" href="<?php echo esc_url( $product_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'جزئیات بیشتر', 'zenless-zone-zero-edd-account-form' ); ?></a>
		<?php if ( ! empty( $card_data['edit_url'] ) ) : ?>
			<a class="zzz-product-card__view-btn zzz-product-card__edit-btn" href="<?php echo esc_url( (string) $card_data['edit_url'] ); ?>"><?php esc_html_e( 'ویرایش', 'zenless-zone-zero-edd-account-form' ); ?></a>
		<?php endif; ?>

		<h3 class="zzz-product-card__title"><a href="<?php echo esc_url( $product_url ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( (string) $card_data['title'] ); ?></a></h3>
	</div>

	<div class="zzz-product-card__tabs" role="tablist" aria-label="<?php esc_attr_e( 'نمایش کارت', 'zenless-zone-zero-edd-account-form' ); ?>">
		<button type="button" class="zzz-product-card__tab is-active" data-zzz-tab-trigger data-target="info-<?php echo esc_attr( (string) $card_id ); ?>" role="tab" aria-selected="true"><?php esc_html_e( 'اطلاعات آکانت', 'zenless-zone-zero-edd-account-form' ); ?></button>
		<button type="button" class="zzz-product-card__tab" data-zzz-tab-trigger data-target="gallery-<?php echo esc_attr( (string) $card_id ); ?>" role="tab" aria-selected="false"><?php esc_html_e( 'گالری تصاویر', 'zenless-zone-zero-edd-account-form' ); ?></button>
		<?php if ( ! empty( $card_data['status_label'] ) ) : ?>
			<span class="zzz-product-card__status-badge <?php echo esc_attr( 'zzz-product-card__status-badge--' . (string) $card_data['status_class'] ); ?>"><?php echo esc_html( (string) $card_data['status_label'] ); ?></span>
		<?php endif; ?>
	</div>

	<div class="zzz-product-card__panel is-active" data-zzz-tab-panel="info-<?php echo esc_attr( (string) $card_id ); ?>" role="tabpanel">
		<div class="zzz-product-card__stats">
			<?php foreach ( $card_data['stats'] as $row ) : ?>
				<div class="zzz-product-card__stat-chip">
					<span class="zzz-product-card__label"><?php echo esc_html( (string) $row['label'] ); ?></span>
					<span class="zzz-product-card__value"><?php echo esc_html( (string) $row['value'] ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="zzz-product-card__footer">
			<div class="zzz-product-card__price-wrap">
				<span class="zzz-product-card__price-label"><?php esc_html_e( 'قیمت', 'zenless-zone-zero-edd-account-form' ); ?></span>
				<strong class="zzz-product-card__price"><?php echo esc_html( (string) $card_data['price'] ); ?></strong>
			</div>


			<div class="zzz-product-card__desktop-only">
				<div class="zzz-product-card__hover" data-zzz-hover>
					<button type="button" class="zzz-product-card__hover-trigger" data-zzz-hover-trigger><?php esc_html_e( 'توضیحات', 'zenless-zone-zero-edd-account-form' ); ?></button>
					<div class="zzz-product-card__hover-content" data-zzz-hover-content>
						<p class="zzz-product-card__hover-text"><?php echo esc_html( (string) $card_data['description_hover'] ); ?></p>
					</div>
				</div>

				<div class="zzz-product-card__hover" data-zzz-hover>
					<button type="button" class="zzz-product-card__hover-trigger" data-zzz-hover-trigger><?php esc_html_e( 'Mindscape Cinema Agentها', 'zenless-zone-zero-edd-account-form' ); ?></button>
					<div class="zzz-product-card__hover-content" data-zzz-hover-content>
						<p class="zzz-product-card__hover-text"><?php echo esc_html( (string) $card_data['mindscape_hover'] ); ?></p>
					</div>
				</div>


				<div class="zzz-product-card__hover" data-zzz-hover>
					<button type="button" class="zzz-product-card__hover-trigger" data-zzz-hover-trigger><?php esc_html_e( 'Agentهای 5 ستاره', 'zenless-zone-zero-edd-account-form' ); ?></button>
					<div class="zzz-product-card__hover-content" data-zzz-hover-content>
						<?php if ( empty( $card_data['characters_hover_items'] ) ) : ?>
							<p class="zzz-product-card__empty">-</p>
						<?php else : ?>
							<ul class="zzz-product-card__mini-list">
								<?php foreach ( $card_data['characters_hover_items'] as $item ) : ?>
									<li class="zzz-product-card__mini-item">
										<?php if ( ! empty( $item['image'] ) ) : ?>
											<img src="<?php echo esc_url( (string) $item['image'] ); ?>" alt="<?php echo esc_attr( (string) $item['name'] ); ?>" loading="lazy" />
										<?php endif; ?>
										<span><?php echo esc_html( (string) $item['name'] ); ?></span>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				</div>

				<div class="zzz-product-card__hover" data-zzz-hover>
					<button type="button" class="zzz-product-card__hover-trigger" data-zzz-hover-trigger><?php esc_html_e( 'Discهای 5 ستاره', 'zenless-zone-zero-edd-account-form' ); ?></button>
					<div class="zzz-product-card__hover-content" data-zzz-hover-content>
						<?php if ( empty( $card_data['discs_hover_items'] ) ) : ?>
							<p class="zzz-product-card__empty">-</p>
						<?php else : ?>
							<ul class="zzz-product-card__mini-list">
								<?php foreach ( $card_data['discs_hover_items'] as $item ) : ?>
									<li class="zzz-product-card__mini-item">
										<?php if ( ! empty( $item['image'] ) ) : ?>
											<img src="<?php echo esc_url( (string) $item['image'] ); ?>" alt="<?php echo esc_attr( (string) $item['name'] ); ?>" loading="lazy" />
										<?php endif; ?>
										<span><?php echo esc_html( (string) $item['name'] ); ?></span>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="zzz-product-card__panel" data-zzz-tab-panel="gallery-<?php echo esc_attr( (string) $card_id ); ?>" role="tabpanel" hidden>
		<?php if ( empty( $card_data['gallery_images'] ) ) : ?>
			<p class="zzz-product-card__empty"><?php esc_html_e( 'تصویری ثبت نشده است.', 'zenless-zone-zero-edd-account-form' ); ?></p>
		<?php else : ?>
			<div class="zzz-gallery" data-zzz-gallery>
				<div class="zzz-gallery__track" data-zzz-gallery-track>
					<?php foreach ( $card_data['gallery_images'] as $image ) : ?>
						<figure class="zzz-gallery__slide">
							<img src="<?php echo esc_url( (string) $image['url'] ); ?>" alt="<?php echo esc_attr( (string) $image['alt'] ); ?>" loading="eager" />
						</figure>
					<?php endforeach; ?>
				</div>
				<?php if ( count( $card_data['gallery_images'] ) > 1 ) : ?>
					<div class="zzz-gallery__actions">
						<button type="button" class="zzz-gallery__btn" data-zzz-gallery-prev aria-label="<?php esc_attr_e( 'قبلی', 'zenless-zone-zero-edd-account-form' ); ?>">‹</button>
						<button type="button" class="zzz-gallery__btn" data-zzz-gallery-next aria-label="<?php esc_attr_e( 'بعدی', 'zenless-zone-zero-edd-account-form' ); ?>">›</button>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>
</article>
