<?php
/**
 * Plugin Name: Zenless Zone Zero EDD Account Form
 * Description: فرم حرفه‌ای ثبت آگهی اکانت Zenless Zone Zero و تبدیل داده‌ها به متای محصول Easy Digital Downloads.
 * Version: 1.1.1
 * Author: Zenless Zone Zero Dev
 * Text Domain: zenless-zone-zero-edd-account-form
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ZZZ_EDD_FORM_VERSION', '1.1.1' );
define( 'ZZZ_EDD_FORM_FILE', __FILE__ );
define( 'ZZZ_EDD_FORM_DIR', plugin_dir_path( __FILE__ ) );
define( 'ZZZ_EDD_FORM_URL', plugin_dir_url( __FILE__ ) );
define( 'ZZZ_EDD_CHARACTERS_IMG_SERVER_PATH', '/domains/gamebani.ir/public_html/wp-content/plugins/zenless-zone-zero-edd-account-form/assets/img/characters' );
define( 'ZZZ_EDD_DISCS_IMG_SERVER_PATH', '/domains/gamebani.ir/public_html/wp-content/plugins/zenless-zone-zero-edd-account-form/assets/img/discs' );
define( 'ZZZ_EDD_CHARACTERS_IMG_BASE_URL', trailingslashit( ZZZ_EDD_FORM_URL . 'assets/img/characters' ) );
define( 'ZZZ_EDD_DISCS_IMG_BASE_URL', trailingslashit( ZZZ_EDD_FORM_URL . 'assets/img/discs' ) );
define( 'ZZZ_EDD_CHARACTERS_IMAGE_EXT', 'png' );
define( 'ZZZ_EDD_DISCS_IMAGE_EXT', 'webp' );

require_once ZZZ_EDD_FORM_DIR . 'includes/class-zzz-edd-account-form-plugin.php';
require_once ZZZ_EDD_FORM_DIR . 'includes/class-zzz-edd-account-form-admin.php';
require_once ZZZ_EDD_FORM_DIR . 'includes/class-zzz-edd-account-form-frontend.php';
require_once ZZZ_EDD_FORM_DIR . 'includes/class-zzz-edd-account-form-product-cards.php';
require_once ZZZ_EDD_FORM_DIR . 'includes/class-zzz-edd-account-form-single-template.php';
require_once ZZZ_EDD_FORM_DIR . 'includes/class-zzz-edd-account-form-home-slider.php';
require_once ZZZ_EDD_FORM_DIR . 'includes/verification-badge.php';
ZZZ_EDD_Account_Form_Plugin::instance();
