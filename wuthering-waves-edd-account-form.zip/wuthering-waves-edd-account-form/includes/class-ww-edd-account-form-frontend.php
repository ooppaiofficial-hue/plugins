<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WW_EDD_Account_Form_Frontend {
	const NONCE_ACTION = 'ww_account_submit';
	const NONCE_UPDATE_ACTION = 'ww_account_update';
	const EDIT_SHORTCODE = 'ww_account_edit_form';
	const EDIT_PAGE_OPTION = 'ww_account_edit_page_id';
	const DOWNLOAD_CATEGORY_TAXONOMY = 'download_category';
	const DOWNLOAD_CATEGORY_SLUG     = 'wuthering-waves-account';
	const DOWNLOAD_CATEGORY_NAME     = 'Wuthering Waves Account';
	const MAX_UPLOAD_IMAGES         = 10;
	const UPLOADED_IMAGE_META_KEY   = 'ww_uploaded_image_ids';
	/**
	 * @var WW_EDD_Account_Form_Admin
	 */
	private $admin;

	/**
	 * @param WW_EDD_Account_Form_Admin $admin Admin dependency.
	 */
	public function __construct( WW_EDD_Account_Form_Admin $admin ) {
		$this->admin = $admin;
	}

	public function register_shortcode() {
		add_shortcode( 'ww_account_form', array( $this, 'render_form_shortcode' ) );
		add_shortcode( self::EDIT_SHORTCODE, array( $this, 'render_edit_form_shortcode' ) );
	}

	public function register_assets() {
		wp_register_style( 'ww-account-form-style', WW_EDD_FORM_URL . 'assets/css/style.css', array(), WW_EDD_FORM_VERSION );
		wp_register_script( 'ww-account-form-script', WW_EDD_FORM_URL . 'assets/js/form.js', array(), WW_EDD_FORM_VERSION, true );
	}

	/**
	 * @return string
	 */
	public function render_form_shortcode() {
		wp_enqueue_style( 'ww-account-form-style' );
		wp_enqueue_script( 'ww-account-form-script' );

		$ww_form_keywords_css = <<<'CSS'
.ww-form-keywords{margin-top:22px;padding-top:14px;border-top:1px solid rgba(125,146,220,.3);}
.ww-form-keywords h3{margin:0 0 10px;font-size:15px;color:#e8f0ff;}
.ww-form-keywords ul{margin:0;padding:0;list-style:none;display:flex;flex-wrap:wrap;gap:8px;}
.ww-form-keywords li{padding:6px 10px;border-radius:999px;background:rgba(79,209,255,.12);border:1px solid rgba(79,209,255,.35);font-size:12px;color:#dce9ff;}
.ww-form-keywords li a{color:inherit;text-decoration:none;}
.ww-form-keywords li a:hover,.ww-form-keywords li a:focus{text-decoration:underline;}
CSS;

		wp_add_inline_style( 'ww-account-form-style', $ww_form_keywords_css );

		if ( ! post_type_exists( 'download' ) ) {
			return '<p class="ww-message ww-error">' . esc_html__( 'Easy Digital Downloads فعال نیست. لطفاً EDD را نصب و فعال کنید.', 'wuthering-waves-edd-account-form' ) . '</p>';
		}

		$success = isset( $_GET['ww_submitted'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['ww_submitted'] ) );
		$server_options = array(
			'asia' => 'Asia',
			'europe' => 'Europe',
			'america' => 'America',
			'taiwan' => 'Taiwan',
		);

		$form_keywords = array(
			'ثبت آگهی آکانت واثرینگ ویوز',
			'ثبت آگهی آکانت wuthering waves',
			'فروش آکانت واثرینگ ویوز',
			'فروش آکانت wuthering waves',
			'ثبت فروش آکانت واثرینگ ویوز',
			'ثبت فروش آکانت wuthering waves',
			'فروش امن آکانت واثرینگ ویوز',
			'فروش امن آکانت wuthering waves',
			'ثبت آگهی فوری آکانت واثرینگ ویوز',
			'ثبت آگهی فوری آکانت wuthering waves',
		);

		$form_keyword_url = 'https://gamebani.ir/sell-wuthering-waves-account/';

		ob_start();
		?>
		<div class="ww-wrap">
			<?php if ( $success ) : ?>
				<div class="ww-message ww-success" role="alert">
					<?php esc_html_e( '✅ آگهی با موفقیت ارسال شد و پس از بررسی منتشر می‌شود.', 'wuthering-waves-edd-account-form' ); ?>
				</div>
			<?php endif; ?>
			<form class="ww-account-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" enctype="multipart/form-data" novalidate>
				<input type="hidden" name="action" value="ww_submit_account" />
				<?php wp_nonce_field( self::NONCE_ACTION, 'ww_nonce' ); ?>

				<div class="ww-grid">
					<?php $this->render_number_field( 'union_level', 'Union Level', 1, 60 ); ?>
					<?php $this->render_custom_select_field( 'server', 'سرور', $server_options ); ?>
					<?php $this->render_number_field( 'resonator_event_convene_pity', 'پیتی بنر Resonator', 1, 90 ); ?>
					<?php $this->render_number_field( 'weapon_event_convene_pity', 'پیتی بنر Weapon', 1, 80 ); ?>
					<?php $this->render_number_field( 'standard_convene_pity', 'پیتی بنر استاندارد', 1, 80 ); ?>
					<?php $this->render_number_field( 'lustrous_tides', 'تعداد Lustrous Tide', 0, 999 ); ?>
					<?php $this->render_number_field( 'astrite', 'Astrite', 0, 999999 ); ?>
					<?php $this->render_number_field( 'lunite', 'Lunite', 0, 999999 ); ?>
					<?php $this->render_number_field( 'radiant_tides', 'تعداد Radiant Tide', 0, 999 ); ?>
				</div>

				<div class="ww-selector-group">
					<h3><?php esc_html_e( 'Resonator 5★', 'wuthering-waves-edd-account-form' ); ?></h3>
					<?php echo $this->render_image_checkbox_list( 'selected_characters', $this->admin->get_character_images(), WW_EDD_CHARACTERS_IMG_BASE_URL, WW_EDD_CHARACTERS_IMAGE_EXT ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>

				<div class="ww-selector-group">
					<h3><?php esc_html_e( 'Weapon 5★', 'wuthering-waves-edd-account-form' ); ?></h3>
					<?php echo $this->render_image_checkbox_list( 'selected_weapons', $this->admin->get_weapon_images(), WW_EDD_WEAPONS_IMG_BASE_URL, WW_EDD_WEAPONS_IMAGE_EXT ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>

				<?php $this->render_number_field( 'price', 'قیمت', 1, 99999999, '', '', 'ww-field-full' ); ?>

				<div class="ww-form-meta-row ww-field-full">
					<div class="ww-field ww-form-meta-row__item">
						<label for="description"><?php esc_html_e( 'توضیحات', 'wuthering-waves-edd-account-form' ); ?></label>
						<textarea id="description" name="description" rows="5" required data-error="لطفاً توضیحات را کامل کنید."></textarea>
					</div>
					<div class="ww-field ww-form-meta-row__item">
						<label for="resonance_chain_summary"><?php esc_html_e( 'Resonance Chain Resonatorها', 'wuthering-waves-edd-account-form' ); ?></label>
						<textarea id="resonance_chain_summary" name="resonance_chain_summary" rows="5" placeholder="R6 Jiyan, R2 Yinlin, R1 Changli, R0 Shorekeeper" required data-error="جزئیات Resonance Chain را وارد کنید."></textarea>
					</div>
				</div>
								<div class="ww-field ww-field-full">
					<input id="ww_images" class="ww-image-input" name="ww_images[]" type="file" accept="image/*" multiple data-max-images="<?php echo esc_attr( self::MAX_UPLOAD_IMAGES ); ?>" />
						<div class="ww-upload-preview" data-upload-preview></div>
				</div>

				<div class="ww-form-feedback" role="alert" aria-live="polite"></div>
								<div class="ww-form-actions">
					<label for="ww_images" class="ww-upload-button"><?php esc_html_e( 'آپلود تصاویر (حداکثر 10)', 'wuthering-waves-edd-account-form' ); ?></label>
					<button type="submit" class="ww-submit"><?php esc_html_e( 'ارسال اکانت Wuthering Waves', 'wuthering-waves-edd-account-form' ); ?></button>
				</div>
			</form>
			<div class="ww-form-keywords" aria-label="کلمات کلیدی فروش">
				<h3><?php esc_html_e( 'کلمات کلیدی فروش', 'wuthering-waves-edd-account-form' ); ?></h3>
				<ul>
					<?php foreach ( $form_keywords as $keyword ) : ?>
						<li><a href="<?php echo esc_url( $form_keyword_url ); ?>"><?php echo esc_html( $keyword ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	private function render_custom_select_field( $name, $label, $options, $selected_value = "" ) {
		?>
		<div class="ww-field">
			<label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></label>
			<div class="ww-custom-select" data-select-wrap>
				<button type="button" class="ww-custom-select__trigger" data-select-trigger aria-expanded="false">
					<span data-select-label><?php echo esc_html( isset( $options[ $selected_value ] ) ? $options[ $selected_value ] : __( 'انتخاب کنید', 'wuthering-waves-edd-account-form' ) ); ?></span>
				</button>
				<ul class="ww-custom-select__menu" data-select-menu hidden>
					<?php foreach ( $options as $value => $option_label ) : ?>
						<li>
							<button type="button" data-option="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $option_label ); ?></button>
						</li>
					<?php endforeach; ?>
				</ul>
				<select id="<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>" required data-error="سرور را انتخاب کنید.">
					<option value=""><?php esc_html_e( 'انتخاب کنید', 'wuthering-waves-edd-account-form' ); ?></option>
					<?php foreach ( $options as $value => $option_label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $selected_value, $value ); ?>><?php echo esc_html( $option_label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		<?php
	}

	private function render_number_field( $name, $label, $min, $max, $suffix = '', $value = '', $extra_class = '' ) {
		$error = sprintf( 'فیلد %s باید بین %d تا %d باشد.', $label, $min, $max );
		?>
		<div class="ww-field <?php echo esc_attr( $extra_class ); ?>">
			<label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></label>
			<div class="ww-number-wrap">
				<input id="<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>" type="number" min="<?php echo esc_attr( $min ); ?>" max="<?php echo esc_attr( $max ); ?>" required value="<?php echo esc_attr( (string) $value ); ?>" data-error="<?php echo esc_attr( $error ); ?>" />
				<?php if ( '' !== $suffix ) : ?>
					<span><?php echo esc_html( $suffix ); ?></span>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	private function render_image_checkbox_list( $name, $items, $base_url = '', $expected_extension = '', $selected_values = array() ) {
		if ( empty( $items ) ) {
			return '<p class="ww-empty">' . esc_html__( 'هنوز تصویری ثبت نشده است. نام فایل‌ها را در تنظیمات وارد کنید.', 'wuthering-waves-edd-account-form' ) . '</p>';
		}

		ob_start();
		echo '<div class="ww-image-grid">';

		foreach ( $items as $index => $item ) {
			if ( empty( $item['name'] ) || empty( $item['file'] ) ) {
				continue;
			}

			$effective_base_url = '' !== (string) $base_url ? (string) $base_url : WW_EDD_CHARACTERS_IMG_BASE_URL;
			$image_file = $this->normalize_file_extension( (string) $item['file'], $expected_extension );
			$image_url = esc_url( $effective_base_url . ltrim( $image_file, '/' ) );
			$input_id  = sanitize_html_class( $name . '-' . $index . '-' . $item['name'] );
			?>
			<label class="ww-card" for="<?php echo esc_attr( $input_id ); ?>">
				<input id="<?php echo esc_attr( $input_id ); ?>" class="ww-card__input" type="checkbox" name="<?php echo esc_attr( $name ); ?>[]" value="<?php echo esc_attr( $item['name'] ); ?>" <?php checked( in_array( $item['name'], $selected_values, true ) ); ?> />
				<span class="ww-card__tick" aria-hidden="true">✓</span>
				<img src="<?php echo $image_url; ?>" alt="<?php echo esc_attr( $item['name'] ); ?>" loading="lazy" />
				<span class="ww-card__name"><?php echo esc_html( $item['name'] ); ?></span>
			</label>
			<?php
		}

		echo '</div>';
		return ob_get_clean();
	}


	public function get_edit_page_url( $post_id ) {
		$post_id = absint( $post_id );
		if ( $post_id <= 0 ) {
			return '';
		}

		$page_id = $this->get_or_create_edit_page_id();
		if ( $page_id <= 0 ) {
			return '';
		}

		return add_query_arg( 'ww_edit_account_id', $post_id, get_permalink( $page_id ) );
	}

	private function get_or_create_edit_page_id() {
		$page_id = absint( get_option( self::EDIT_PAGE_OPTION, 0 ) );
		if ( $page_id > 0 && 'publish' === get_post_status( $page_id ) ) {
			return $page_id;
		}

		$existing = get_page_by_path( 'ww-account-edit' );
		if ( $existing instanceof WP_Post ) {
			wp_update_post(
				array(
					'ID'         => (int) $existing->ID,
					'post_title' => '',
				)
			);
			update_option( self::EDIT_PAGE_OPTION, (int) $existing->ID );
			return (int) $existing->ID;
		}

		$new_page_id = wp_insert_post(
			array(
				'post_title'   => '',
				'post_name'    => 'ww-account-edit',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => '[' . self::EDIT_SHORTCODE . ']',
			),
			true
		);

		if ( is_wp_error( $new_page_id ) ) {
			return 0;
		}

		update_option( self::EDIT_PAGE_OPTION, (int) $new_page_id );
		return (int) $new_page_id;
	}

	public function render_edit_form_shortcode() {
		if ( ! is_user_logged_in() ) {
			return '<p class="ww-message ww-error">' . esc_html__( 'برای ویرایش آکانت ابتدا وارد شوید.', 'wuthering-waves-edd-account-form' ) . '</p>';
		}

		$post_id = isset( $_GET['ww_edit_account_id'] ) ? absint( wp_unslash( $_GET['ww_edit_account_id'] ) ) : 0;
		$post    = $post_id > 0 ? get_post( $post_id ) : null;
		if ( ! $post || 'download' !== $post->post_type || (int) $post->post_author !== get_current_user_id() ) {
			return '<p class="ww-message ww-error">' . esc_html__( 'آکانت معتبری برای ویرایش پیدا نشد.', 'wuthering-waves-edd-account-form' ) . '</p>';
		}

		wp_enqueue_style( 'ww-account-form-style' );
		wp_enqueue_script( 'ww-account-form-script' );

		$server_options = array(
			'asia' => 'Asia',
			'europe' => 'Europe',
			'america' => 'America',
			'taiwan' => 'Taiwan',
		);

		$values = array(
			'union_level'          => (string) get_post_meta( $post_id, 'ww_union_level', true ),
			'server'                    => (string) get_post_meta( $post_id, 'ww_server', true ),
			'resonator_event_convene_pity' => (string) get_post_meta( $post_id, 'ww_resonator_event_convene_pity', true ),
			'weapon_event_convene_pity' => (string) get_post_meta( $post_id, 'ww_weapon_event_convene_pity', true ),
			'standard_convene_pity'        => (string) get_post_meta( $post_id, 'ww_standard_convene_pity', true ),
			'lustrous_tides'          => (string) get_post_meta( $post_id, 'ww_lustrous_tides', true ),
			'astrite'              => (string) get_post_meta( $post_id, 'ww_astrite', true ),
			'lunite'             => (string) get_post_meta( $post_id, 'ww_lunite', true ),
			'radiant_tides'            => (string) get_post_meta( $post_id, 'ww_radiant_tides', true ),
			'resonance_chain_summary'          => (string) get_post_meta( $post_id, 'ww_resonance_chain_summary', true ),
			'price'                     => (string) get_post_meta( $post_id, 'edd_price', true ),
			'description'               => (string) $post->post_content,
			'selected_characters'       => $this->extract_meta_list( (string) get_post_meta( $post_id, 'ww_selected_characters', true ) ),
			'selected_weapons'      => $this->extract_meta_list( (string) get_post_meta( $post_id, 'ww_selected_weapons', true ) ),
			'existing_images'            => $this->get_uploaded_images_data( $post_id ),
		);

		$updated = isset( $_GET['ww_updated'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['ww_updated'] ) );

		ob_start();
		?>
		<div class="ww-wrap ww-wrap--full ww-edit-page-wrap">
			<?php if ( $updated ) : ?>
				<div class="ww-message ww-success" role="alert"><?php esc_html_e( '✅ آکانت با موفقیت بروزرسانی شد و برای بررسی ارسال گردید.', 'wuthering-waves-edd-account-form' ); ?></div>
			<?php endif; ?>
			<form class="ww-account-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" enctype="multipart/form-data" novalidate>
				<input type="hidden" name="action" value="ww_update_account" />
				<input type="hidden" name="account_id" value="<?php echo esc_attr( (string) $post_id ); ?>" />
				<?php wp_nonce_field( self::NONCE_UPDATE_ACTION, 'ww_nonce' ); ?>
				<div class="ww-grid">
					<?php $this->render_number_field( 'union_level', 'Union Level', 1, 60, '', $values['union_level'] ); ?>
					<?php $this->render_custom_select_field( 'server', 'سرور', $server_options, $values['server'] ); ?>
					<?php $this->render_number_field( 'resonator_event_convene_pity', 'پیتی بنر Resonator', 1, 90, '', $values['resonator_event_convene_pity'] ); ?>
					<?php $this->render_number_field( 'weapon_event_convene_pity', 'پیتی بنر Weapon', 1, 80, '', $values['weapon_event_convene_pity'] ); ?>
					<?php $this->render_number_field( 'standard_convene_pity', 'پیتی بنر استاندارد', 1, 80, '', $values['standard_convene_pity'] ); ?>
					<?php $this->render_number_field( 'lustrous_tides', 'تعداد Lustrous Tide', 0, 999, '', $values['lustrous_tides'] ); ?>
					<?php $this->render_number_field( 'astrite', 'Astrite', 0, 999999, '', $values['astrite'] ); ?>
					<?php $this->render_number_field( 'lunite', 'Lunite', 0, 999999, '', $values['lunite'] ); ?>
					<?php $this->render_number_field( 'radiant_tides', 'تعداد Radiant Tide', 0, 999, '', $values['radiant_tides'] ); ?>
				</div>

				<div class="ww-selector-group">
					<h3><?php esc_html_e( 'Resonator 5★', 'wuthering-waves-edd-account-form' ); ?></h3>
					<?php echo $this->render_image_checkbox_list( 'selected_characters', $this->admin->get_character_images(), WW_EDD_CHARACTERS_IMG_BASE_URL, WW_EDD_CHARACTERS_IMAGE_EXT, $values['selected_characters'] ); ?>
				</div>

				<div class="ww-selector-group">
					<h3><?php esc_html_e( 'Weapon 5★', 'wuthering-waves-edd-account-form' ); ?></h3>
					<?php echo $this->render_image_checkbox_list( 'selected_weapons', $this->admin->get_weapon_images(), WW_EDD_WEAPONS_IMG_BASE_URL, WW_EDD_WEAPONS_IMAGE_EXT, $values['selected_weapons'] ); ?>
				</div>

				<?php $this->render_number_field( 'price', 'قیمت', 1, 99999999, '', $values['price'], 'ww-field-full' ); ?>

				<div class="ww-form-meta-row ww-field-full">
					<div class="ww-field ww-form-meta-row__item">
						<label for="description"><?php esc_html_e( 'توضیحات', 'wuthering-waves-edd-account-form' ); ?></label>
						<textarea id="description" name="description" rows="5" required data-error="لطفاً توضیحات را کامل کنید."><?php echo esc_textarea( $values['description'] ); ?></textarea>
					</div>
					<div class="ww-field ww-form-meta-row__item">
						<label for="resonance_chain_summary"><?php esc_html_e( 'Resonance Chain Resonatorها', 'wuthering-waves-edd-account-form' ); ?></label>
						<textarea id="resonance_chain_summary" name="resonance_chain_summary" rows="5" placeholder="R6 Jiyan, R2 Yinlin, R1 Changli, R0 Shorekeeper" required data-error="جزئیات Resonance Chain را وارد کنید."><?php echo esc_textarea( $values['resonance_chain_summary'] ); ?></textarea>
					</div>
				</div>

				<div class="ww-field ww-field-full">
					<input id="ww_images" class="ww-image-input" name="ww_images[]" type="file" accept="image/*" multiple data-max-images="<?php echo esc_attr( self::MAX_UPLOAD_IMAGES ); ?>" />
					<div class="ww-upload-preview" data-upload-preview>
						<?php foreach ( $values['existing_images'] as $existing_image ) : ?>
							<div class="ww-upload-preview__item">
								<img src="<?php echo esc_url( (string) $existing_image['url'] ); ?>" alt="<?php echo esc_attr( (string) $existing_image['alt'] ); ?>" loading="lazy" />
								<span><?php echo esc_html( (string) $existing_image['name'] ); ?></span>
							</div>
						<?php endforeach; ?>
					</div>
				</div>

				<div class="ww-form-feedback" role="alert" aria-live="polite"></div>
				<div class="ww-form-actions">
					<label for="ww_images" class="ww-upload-button"><?php esc_html_e( 'آپلود تصاویر (حداکثر 10)', 'wuthering-waves-edd-account-form' ); ?></label>
					<button type="submit" class="ww-submit"><?php esc_html_e( 'بروزرسانی', 'wuthering-waves-edd-account-form' ); ?></button>
				</div>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	public function handle_submission() {
		if ( ! isset( $_POST['ww_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ww_nonce'] ) ), self::NONCE_ACTION ) ) {
			wp_die( esc_html__( 'درخواست نامعتبر است.', 'wuthering-waves-edd-account-form' ) );
		}

		if ( ! post_type_exists( 'download' ) ) {
			wp_die( esc_html__( 'Easy Digital Downloads فعال نیست.', 'wuthering-waves-edd-account-form' ) );
		}

		$server_whitelist = array( 'asia', 'europe', 'america', 'taiwan' );
		$server           = isset( $_POST['server'] ) ? sanitize_text_field( wp_unslash( $_POST['server'] ) ) : '';
		if ( ! in_array( $server, $server_whitelist, true ) ) {
			wp_die( esc_html__( 'سرور انتخابی معتبر نیست.', 'wuthering-waves-edd-account-form' ) );
		}

		$allowed_character_names = $this->extract_allowed_item_names( $this->admin->get_character_images() );
		$allowed_weapon_names    = $this->extract_allowed_item_names( $this->admin->get_weapon_images() );

		$data = array(
			'union_level'       => $this->sanitize_bounded_number( 'union_level', 1, 60 ),
			'server'                => $server,
			'resonator_event_convene_pity' => $this->sanitize_bounded_number( 'resonator_event_convene_pity', 1, 90 ),
			'weapon_event_convene_pity'    => $this->sanitize_bounded_number( 'weapon_event_convene_pity', 1, 80 ),
			'standard_convene_pity'  => $this->sanitize_bounded_number( 'standard_convene_pity', 1, 80 ),
			'lustrous_tides'        => $this->sanitize_bounded_number( 'lustrous_tides', 0, 999 ),
			'astrite'               => $this->sanitize_bounded_number( 'astrite', 0, 999999 ),
			'lunite'             => $this->sanitize_bounded_number( 'lunite', 0, 999999 ),
			'radiant_tides'        => $this->sanitize_bounded_number( 'radiant_tides', 0, 999 ),
			'resonance_chain_summary'   => isset( $_POST['resonance_chain_summary'] ) ? sanitize_text_field( wp_unslash( $_POST['resonance_chain_summary'] ) ) : '',
			'description'           => isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '',
			'price'                 => $this->sanitize_bounded_number( 'price', 1, 99999999 ),
			'selected_characters'   => $this->sanitize_text_list( isset( $_POST['selected_characters'] ) ? wp_unslash( $_POST['selected_characters'] ) : array(), $allowed_character_names ),
			'selected_weapons'      => $this->sanitize_text_list( isset( $_POST['selected_weapons'] ) ? wp_unslash( $_POST['selected_weapons'] ) : array(), $allowed_weapon_names ),
		);

		if ( '' === $data['resonance_chain_summary'] || '' === $data['description'] ) {
			wp_die( esc_html__( 'لطفاً تمام فیلدهای الزامی را تکمیل کنید.', 'wuthering-waves-edd-account-form' ) );
		}

		$seo_titles = $this->build_seo_titles( $data['server'], (int) $data['union_level'] );

		$post_id = wp_insert_post(
			array(
				'post_title'   => $seo_titles['primary'],
				'post_type'    => 'download',
				'post_status'  => 'pending',
				'post_content' => $data['description'],
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			wp_die( esc_html__( 'خطا در ثبت آگهی. دوباره تلاش کنید.', 'wuthering-waves-edd-account-form' ) );
		}

		$this->assign_download_category( $post_id );

		update_post_meta( $post_id, 'edd_price', $data['price'] );
		foreach ( $data as $meta_key => $meta_value ) {
			if ( 'price' === $meta_key ) {
				continue;
			}

			if ( is_array( $meta_value ) && empty( $meta_value ) ) {
				continue;
			}

			update_post_meta( $post_id, 'ww_' . $meta_key, is_array( $meta_value ) ? implode( ', ', $meta_value ) : $meta_value );
		}

		$this->handle_uploaded_images( $post_id );

		wp_safe_redirect( add_query_arg( 'ww_submitted', '1', wp_get_referer() ? wp_get_referer() : home_url() ) );
		exit;
	}



	private function get_uploaded_images_data( $post_id ) {
		$image_ids = $this->extract_meta_list( (string) get_post_meta( $post_id, self::UPLOADED_IMAGE_META_KEY, true ) );
		$images    = array();

		foreach ( $image_ids as $id_raw ) {
			$attachment_id = absint( $id_raw );
			if ( $attachment_id <= 0 ) {
				continue;
			}

			$image_url = wp_get_attachment_image_url( $attachment_id, 'medium' );
			if ( ! $image_url ) {
				continue;
			}

			$alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
			if ( '' === $alt ) {
				$alt = get_the_title( $attachment_id );
			}

			$images[] = array(
				'url'  => esc_url( $image_url ),
				'alt'  => sanitize_text_field( (string) $alt ),
				'name' => sanitize_text_field( (string) wp_basename( (string) wp_get_attachment_url( $attachment_id ) ) ),
			);
		}

		return $images;
	}

	public function handle_update_submission() {
		if ( ! is_user_logged_in() ) {
			wp_die( esc_html__( 'برای ویرایش آکانت ابتدا وارد شوید.', 'wuthering-waves-edd-account-form' ) );
		}

		if ( ! isset( $_POST['ww_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ww_nonce'] ) ), self::NONCE_UPDATE_ACTION ) ) {
			wp_die( esc_html__( 'درخواست نامعتبر است.', 'wuthering-waves-edd-account-form' ) );
		}

		$post_id = isset( $_POST['account_id'] ) ? absint( wp_unslash( $_POST['account_id'] ) ) : 0;
		$post    = $post_id > 0 ? get_post( $post_id ) : null;
		if ( ! $post || 'download' !== $post->post_type || (int) $post->post_author !== get_current_user_id() ) {
			wp_die( esc_html__( 'شما اجازه ویرایش این آکانت را ندارید.', 'wuthering-waves-edd-account-form' ) );
		}

		$server_whitelist = array( 'asia', 'europe', 'america', 'taiwan' );
		$server           = isset( $_POST['server'] ) ? sanitize_text_field( wp_unslash( $_POST['server'] ) ) : '';
		if ( ! in_array( $server, $server_whitelist, true ) ) {
			wp_die( esc_html__( 'سرور انتخابی معتبر نیست.', 'wuthering-waves-edd-account-form' ) );
		}

		$allowed_character_names = $this->extract_allowed_item_names( $this->admin->get_character_images() );
		$allowed_weapon_names    = $this->extract_allowed_item_names( $this->admin->get_weapon_images() );

		$data = array(
			'union_level'          => $this->sanitize_bounded_number( 'union_level', 1, 60 ),
			'server'                    => $server,
			'resonator_event_convene_pity' => $this->sanitize_bounded_number( 'resonator_event_convene_pity', 1, 90 ),
			'weapon_event_convene_pity' => $this->sanitize_bounded_number( 'weapon_event_convene_pity', 1, 80 ),
			'standard_convene_pity'        => $this->sanitize_bounded_number( 'standard_convene_pity', 1, 80 ),
			'lustrous_tides'          => $this->sanitize_bounded_number( 'lustrous_tides', 0, 999 ),
			'astrite'              => $this->sanitize_bounded_number( 'astrite', 0, 999999 ),
			'lunite'             => $this->sanitize_bounded_number( 'lunite', 0, 999999 ),
			'radiant_tides'            => $this->sanitize_bounded_number( 'radiant_tides', 0, 999 ),
			'resonance_chain_summary'          => isset( $_POST['resonance_chain_summary'] ) ? sanitize_text_field( wp_unslash( $_POST['resonance_chain_summary'] ) ) : '',
			'description'               => isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '',
			'price'                     => $this->sanitize_bounded_number( 'price', 1, 99999999 ),
			'selected_characters'       => $this->sanitize_text_list( isset( $_POST['selected_characters'] ) ? wp_unslash( $_POST['selected_characters'] ) : array(), $allowed_character_names ),
			'selected_weapons'      => $this->sanitize_text_list( isset( $_POST['selected_weapons'] ) ? wp_unslash( $_POST['selected_weapons'] ) : array(), $allowed_weapon_names ),
		);

		$seo_titles = $this->build_seo_titles( $data['server'], (int) $data['union_level'] );

		wp_update_post(
			array(
				'ID'           => $post_id,
				'post_title'   => $seo_titles['primary'],
				'post_content' => $data['description'],
				'post_status'  => 'pending',
			)
		);

		update_post_meta( $post_id, 'edd_price', $data['price'] );
		foreach ( $data as $meta_key => $meta_value ) {
			if ( 'price' === $meta_key ) {
				continue;
			}
			update_post_meta( $post_id, 'ww_' . $meta_key, is_array( $meta_value ) ? implode( ', ', $meta_value ) : $meta_value );
		}

		$this->handle_uploaded_images( $post_id );
		$redirect = $this->get_edit_page_url( $post_id );
		if ( '' === $redirect ) {
			$redirect = home_url();
		}

		wp_safe_redirect( add_query_arg( array( 'ww_updated' => '1', 'ww_edit_account_id' => $post_id ), $redirect ) );
		exit;
	}

	private function extract_meta_list( $meta ) {
		if ( '' === $meta ) {
			return array();
		}

		$items = array_map( 'trim', explode( ',', $meta ) );
		$items = array_filter(
			$items,
			static function ( $item ) {
				return '' !== $item;
			}
		);

		return array_values( array_unique( $items ) );
	}

			private function assign_download_category( $post_id ) {
		if ( ! taxonomy_exists( self::DOWNLOAD_CATEGORY_TAXONOMY ) ) {
			return;
		}

		$term = get_term_by( 'slug', self::DOWNLOAD_CATEGORY_SLUG, self::DOWNLOAD_CATEGORY_TAXONOMY );

		if ( ! $term || is_wp_error( $term ) ) {
			$term_result = wp_insert_term(
				self::DOWNLOAD_CATEGORY_NAME,
				self::DOWNLOAD_CATEGORY_TAXONOMY,
				array(
					'slug' => self::DOWNLOAD_CATEGORY_SLUG,
				)
			);

			if ( is_wp_error( $term_result ) || empty( $term_result['term_id'] ) ) {
				return;
			}

			$term_id = (int) $term_result['term_id'];
		} else {
			$term_id = (int) $term->term_id;
		}

		if ( $term_id > 0 ) {
			wp_set_object_terms( $post_id, array( $term_id ), self::DOWNLOAD_CATEGORY_TAXONOMY, false );
		}
	}


	private function handle_uploaded_images( $post_id ) {
		if ( empty( $_FILES['ww_images'] ) || empty( $_FILES['ww_images']['name'] ) ) {
			return;
		}

		$names = isset( $_FILES['ww_images']['name'] ) && is_array( $_FILES['ww_images']['name'] ) ? $_FILES['ww_images']['name'] : array();
		if ( count( $names ) > self::MAX_UPLOAD_IMAGES ) {
			wp_die( esc_html__( 'حداکثر 10 تصویر قابل آپلود است.', 'wuthering-waves-edd-account-form' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$uploaded_image_ids = array();
		$files              = $_FILES['ww_images'];

		foreach ( $names as $index => $name ) {
			if ( empty( $name ) ) {
				continue;
			}

			if ( empty( $files['type'][ $index ] ) || 0 !== strpos( (string) $files['type'][ $index ], 'image/' ) ) {
				continue;
			}

			$_FILES['ww_single_upload'] = array(
				'name'     => $files['name'][ $index ],
				'type'     => $files['type'][ $index ],
				'tmp_name' => $files['tmp_name'][ $index ],
				'error'    => $files['error'][ $index ],
				'size'     => $files['size'][ $index ],
			);

			$attachment_id = media_handle_upload( 'ww_single_upload', $post_id );
			if ( ! is_wp_error( $attachment_id ) ) {
				$uploaded_image_ids[] = (int) $attachment_id;
			}
		}

		unset( $_FILES['ww_single_upload'] );

		if ( ! empty( $uploaded_image_ids ) ) {
			update_post_meta( $post_id, self::UPLOADED_IMAGE_META_KEY, implode( ',', $uploaded_image_ids ) );
		}
	}

	private function sanitize_bounded_number( $field_name, $min, $max ) {
		$value = isset( $_POST[ $field_name ] ) ? absint( wp_unslash( $_POST[ $field_name ] ) ) : 0;
		if ( $value < $min || $value > $max ) {
			wp_die( esc_html__( 'مقدار عددی خارج از بازه مجاز است.', 'wuthering-waves-edd-account-form' ) );
		}
		return $value;
	}

	private function sanitize_text_list( $values, $allowed = array() ) {
		if ( ! is_array( $values ) ) {
			return array();
		}

		$clean = array();
		foreach ( $values as $value ) {
			$text = sanitize_text_field( $value );
			if ( '' === $text ) {
				continue;
			}

			if ( ! empty( $allowed ) && ! in_array( $text, $allowed, true ) ) {
				continue;
			}

			$clean[] = $text;
		}

		return array_values( array_unique( $clean ) );
	}

	private function build_seo_titles( $server, $union_level ) {
		$server_label = strtoupper( sanitize_text_field( (string) $server ) );
		$level        = max( 1, absint( $union_level ) );

		return array(
			'primary' => sprintf( 'wuthering waves account - %1$s - UL %2$d', $server_label, $level ),
			'fa'      => sprintf( 'آکانت واثرینگ ویوز - %1$s - UL %2$d', $server_label, $level ),
		);
	}

	private function normalize_file_extension( $file_name, $expected_extension ) {
		$file_name = sanitize_file_name( (string) $file_name );
		$expected_extension = sanitize_key( (string) $expected_extension );

		if ( '' === $file_name || '' === $expected_extension ) {
			return $file_name;
		}

		$base = pathinfo( $file_name, PATHINFO_FILENAME );
		if ( '' === $base ) {
			return $file_name;
		}

		return $base . '.' . $expected_extension;
	}

	private function extract_allowed_item_names( $items ) {
		if ( ! is_array( $items ) ) {
			return array();
		}

		$names = array();
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) || empty( $item['name'] ) ) {
				continue;
			}
			$name = sanitize_text_field( $item['name'] );
			if ( '' !== $name ) {
				$names[] = $name;
			}
		}

		return array_values( array_unique( $names ) );
	}

}
