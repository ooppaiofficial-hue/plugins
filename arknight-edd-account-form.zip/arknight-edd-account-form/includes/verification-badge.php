<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'arkn_is_user_identity_verified' ) ) {
	/**
	 * Check whether a user is identity-verified by Gaming User Dashboard plugin.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	function arkn_is_user_identity_verified( $user_id ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return false;
		}

		$status = (string) get_user_meta( $user_id, 'gud_verification_status', true );
		return 'approved' === $status;
	}
}

if ( ! function_exists( 'arkn_get_verified_badge_html' ) ) {
	/**
	 * Render a verification badge for approved users.
	 *
	 * @param int                  $user_id User ID.
	 * @param array<string,string> $args    Badge options.
	 * @return string
	 */
	function arkn_get_verified_badge_html( $user_id, $args = array() ) {
		if ( ! arkn_is_user_identity_verified( $user_id ) ) {
			return '';
		}

		$args = wp_parse_args(
			$args,
			array(
				'class' => '',
				'label' => 'احراز هویت شده',
			)
		);

		$extra_class   = isset( $args['class'] ) ? (string) $args['class'] : '';
		$badge_classes = trim( 'arkn-verified-badge ' . $extra_class );
		$label         = isset( $args['label'] ) ? (string) $args['label'] : 'احراز هویت شده';

		return sprintf(
			'<span class="%1$s" role="img" aria-label="%2$s"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 2.5 9.3 4.7l-3.4-.1-.8 3.3-2.6 2.1 1.4 3-1.4 3 2.6 2.1.8 3.3 3.4-.1 2.7 2.2 2.7-2.2 3.4.1.8-3.3 2.6-2.1-1.4-3 1.4-3-2.6-2.1-.8-3.3-3.4.1L12 2.5Zm-1 14.4-3.2-3.2 1.4-1.4 1.8 1.8 4.2-4.2 1.4 1.4-5.6 5.6Z"></path></svg><span class="arkn-verified-tooltip">%2$s</span></span>',
			esc_attr( $badge_classes ),
			esc_attr( $label )
		);
	}
}

if ( ! function_exists( 'arkn_get_user_display_name' ) ) {
	/**
	 * Resolve seller name using the same public profile scenario from Steam Connect Pro:
	 * display_name -> steam_name -> user_login.
	 *
	 * @param int $user_id User ID.
	 * @return string
	 */
	function arkn_get_user_display_name( $user_id ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return '';
		}

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return '';
		}

		$display_name = sanitize_text_field( trim( (string) $user->display_name ) );
		if ( '' !== $display_name ) {
			return $display_name;
		}

		$steam_name = sanitize_text_field( (string) get_user_meta( $user_id, 'steam_name', true ) );
		if ( '' !== $steam_name ) {
			return $steam_name;
		}

		return sanitize_user( (string) $user->user_login, true );
	}
}

if ( ! function_exists( 'arkn_get_user_avatar_url' ) ) {
	/**
	 * Resolve seller avatar using Steam Connect Pro scenario:
	 * WordPress custom avatar -> Steam avatar -> default avatar.
	 *
	 * @param int $user_id User ID.
	 * @param int $size    Avatar size.
	 * @return string
	 */
	function arkn_get_user_avatar_url( $user_id, $size = 96 ) {
		$user_id = absint( $user_id );
		$size    = max( 24, absint( $size ) );
		if ( $user_id <= 0 ) {
			return '';
		}

		if ( function_exists( 'scp_get_user_avatar_url' ) ) {
			$avatar = (string) scp_get_user_avatar_url( $user_id, $size );
			if ( '' !== $avatar ) {
				return esc_url_raw( $avatar );
			}
		}

		$avatar_data   = get_avatar_data( $user_id, array( 'size' => $size ) );
		$wp_avatar_url = ! empty( $avatar_data['url'] ) ? esc_url_raw( (string) $avatar_data['url'] ) : '';

		if ( '' !== $wp_avatar_url ) {
			return $wp_avatar_url;
		}

		$steam_avatar = esc_url_raw( (string) get_user_meta( $user_id, 'steam_avatar', true ) );
		if ( '' !== $steam_avatar ) {
			return $steam_avatar;
		}

		return esc_url_raw( get_avatar_url( $user_id, array( 'size' => $size ) ) );
	}
}


if ( ! function_exists( 'arkn_get_user_public_profile_url' ) ) {
	/**
	 * Build Steam Connect Pro public profile URL for a site user.
	 *
	 * @param int $user_id User ID.
	 * @return string
	 */
	function arkn_get_user_public_profile_url( $user_id ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return '';
		}

		return esc_url_raw( add_query_arg( 'scp_site_user', $user_id, home_url( '/' ) ) );
	}
}
