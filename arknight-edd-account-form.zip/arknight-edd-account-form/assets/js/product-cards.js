(function () {
	'use strict';

	const initArknProductCards = (root = document) => {
		const cardsRoot = root.querySelector('[data-arkn-cards]');
		if (!cardsRoot || cardsRoot.dataset.arknInitialized === '1') {
			return;
		}
		cardsRoot.dataset.arknInitialized = '1';

		const filtersRoot = root.querySelector('[data-arkn-filters]');

		const closeAllHovers = () => {
			cardsRoot.querySelectorAll('[data-arkn-hover].is-open').forEach((openItem) => {
				openItem.classList.remove('is-open');
			});
		};

		cardsRoot.querySelectorAll('[data-arkn-hover-trigger]').forEach((trigger) => {
			trigger.addEventListener('click', (event) => {
				event.preventDefault();
				const item = trigger.closest('[data-arkn-hover]');
				if (!item) {
					return;
				}

				const isOpen = item.classList.contains('is-open');
				closeAllHovers();
				if (!isOpen) {
					item.classList.add('is-open');
				}
			});
		});

		document.addEventListener('click', (event) => {
			if (!cardsRoot.contains(event.target)) {
				closeAllHovers();
			}
		});

		cardsRoot.querySelectorAll('[data-arkn-card]').forEach((card) => {
			const tabTriggers = card.querySelectorAll('[data-arkn-tab-trigger]');
			const panels = card.querySelectorAll('[data-arkn-tab-panel]');

			tabTriggers.forEach((trigger) => {
				trigger.addEventListener('click', () => {
					const target = trigger.getAttribute('data-target');
					if (!target) {
						return;
					}

					tabTriggers.forEach((item) => {
						item.classList.remove('is-active');
						item.setAttribute('aria-selected', 'false');
					});
					trigger.classList.add('is-active');
					trigger.setAttribute('aria-selected', 'true');

					panels.forEach((panel) => {
						const isTarget = panel.getAttribute('data-arkn-tab-panel') === target;
						panel.classList.toggle('is-active', isTarget);
						panel.hidden = !isTarget;
					});
				});
			});

			card.querySelectorAll('[data-arkn-gallery]').forEach((gallery) => {
				const track = gallery.querySelector('[data-arkn-gallery-track]');
				const slides = gallery.querySelectorAll('.arkn-gallery__slide');
				const prevBtn = gallery.querySelector('[data-arkn-gallery-prev]');
				const nextBtn = gallery.querySelector('[data-arkn-gallery-next]');

				if (!track || slides.length <= 1 || !prevBtn || !nextBtn) {
					return;
				}

				let index = 0;
				const total = slides.length;
				const isRtl = window.getComputedStyle(gallery).direction === 'rtl';
				const render = () => {
					const directionMultiplier = isRtl ? 100 : -100;
					track.style.transform = `translateX(${index * directionMultiplier}%)`;
				};

				prevBtn.addEventListener('click', () => {
					index = (index - 1 + total) % total;
					render();
				});

				nextBtn.addEventListener('click', () => {
					index = (index + 1) % total;
					render();
				});

				render();
			});
		});

		if (!filtersRoot || filtersRoot.dataset.arknInitialized === '1') {
			return;
		}
		filtersRoot.dataset.arknInitialized = '1';

		const cards = Array.from(cardsRoot.querySelectorAll('[data-arkn-card]'));
		const authorityMin = filtersRoot.querySelector('[data-arkn-filter="authority-min"]');
		const authorityMax = filtersRoot.querySelector('[data-arkn-filter="authority-max"]');
		const serverInput = filtersRoot.querySelector('[data-arkn-filter="server"]');
		const priceMin = filtersRoot.querySelector('[data-arkn-filter="price-min"]');
		const priceMax = filtersRoot.querySelector('[data-arkn-filter="price-max"]');
		const sortInput = filtersRoot.querySelector('[data-arkn-filter="sort"]');
		const characterChecks = Array.from(filtersRoot.querySelectorAll('[data-arkn-filter="character"]'));
		const weaponChecks = Array.from(filtersRoot.querySelectorAll('[data-arkn-filter="weapon"]'));

		const readJson = (raw) => {
			if (!raw) {
				return [];
			}
			try {
				const parsed = JSON.parse(raw);
				return Array.isArray(parsed) ? parsed : [];
			} catch (error) {
				return [];
			}
		};

		const selectedFrom = (inputs) =>
			inputs.filter((input) => input.checked).map((input) => input.value.trim()).filter(Boolean);

		const runFiltersWithoutJump = () => {
			const previousY = window.scrollY;
			applyFilters();
			if (Math.abs(window.scrollY - previousY) > 4) {
				window.scrollTo({ top: previousY, behavior: 'auto' });
			}
		};

		const applyFilters = () => {
			const authMin = Math.max(1, Math.min(60, parseInt(authorityMin?.value || '1', 10) || 1));
			const authMax = Math.max(1, Math.min(60, parseInt(authorityMax?.value || '60', 10) || 60));
			const minAuth = Math.min(authMin, authMax);
			const maxAuth = Math.max(authMin, authMax);
			const selectedServer = (serverInput?.value || '').trim();
			const minPrice = parseFloat(priceMin?.value || '0') || 0;
			const maxPriceInput = parseFloat(priceMax?.value || '0') || 0;
			const maxPrice = maxPriceInput > 0 ? maxPriceInput : Number.MAX_SAFE_INTEGER;
			const selectedCharacters = selectedFrom(characterChecks);
			const selectedWeapons = selectedFrom(weaponChecks);
			const sortBy = sortInput?.value || 'newest';

			const visible = [];
			cards.forEach((card) => {
				const authority = parseInt(card.getAttribute('data-authority-level') || '0', 10) || 0;
				const server = (card.getAttribute('data-server') || '').trim();
				const price = parseFloat(card.getAttribute('data-price') || '0') || 0;
				const characters = readJson(card.getAttribute('data-characters'));
				const weapons = readJson(card.getAttribute('data-weapons'));

				const authorityMatch = authority >= minAuth && authority <= maxAuth;
				const serverMatch = !selectedServer || selectedServer === server;
				const priceMatch = price >= minPrice && price <= maxPrice;
				const characterMatch = selectedCharacters.every((value) => characters.includes(value));
				const weaponMatch = selectedWeapons.every((value) => weapons.includes(value));

				const isMatch = authorityMatch && serverMatch && priceMatch && characterMatch && weaponMatch;
				card.style.display = isMatch ? '' : 'none';
				if (isMatch) {
					visible.push(card);
				}
			});

			visible.sort((a, b) => {
				const createdA = parseInt(a.getAttribute('data-created-at') || '0', 10) || 0;
				const createdB = parseInt(b.getAttribute('data-created-at') || '0', 10) || 0;
				const priceA = parseFloat(a.getAttribute('data-price') || '0') || 0;
				const priceB = parseFloat(b.getAttribute('data-price') || '0') || 0;

				if (sortBy === 'min-price') {
					return priceA - priceB;
				}
				if (sortBy === 'max-price') {
					return priceB - priceA;
				}
				if (sortBy === 'oldest') {
					return createdA - createdB;
				}
				return createdB - createdA;
			});

			visible.forEach((card) => cardsRoot.appendChild(card));
		};

		filtersRoot.querySelectorAll('input, select').forEach((input) => {
			input.addEventListener('input', runFiltersWithoutJump);
			input.addEventListener('change', runFiltersWithoutJump);
		});

		const selectRoots = Array.from(filtersRoot.querySelectorAll('[data-arkn-custom-select]'));
		if (selectRoots.length > 0) {
			const closeAllMenus = () => {
				selectRoots.forEach((item) => {
					const trigger = item.querySelector('[data-arkn-select-trigger]');
					const menu = item.querySelector('[data-arkn-select-menu]');
					if (menu) {
						menu.setAttribute('hidden', 'hidden');
					}
					trigger?.setAttribute('aria-expanded', 'false');
				});
			};

			selectRoots.forEach((selectRoot) => {
				const trigger = selectRoot.querySelector('[data-arkn-select-trigger]');
				const menu = selectRoot.querySelector('[data-arkn-select-menu]');
				const label = selectRoot.querySelector('[data-arkn-select-label]');
				const hiddenInput = selectRoot.querySelector('input[type="hidden"][data-arkn-filter]');

				trigger?.addEventListener('click', () => {
					if (!menu) {
						return;
					}
					const isOpen = !menu.hasAttribute('hidden');
					closeAllMenus();
					if (!isOpen) {
						menu.removeAttribute('hidden');
						trigger.setAttribute('aria-expanded', 'true');
					}
				});

				menu?.querySelectorAll('button[data-value]').forEach((btn) => {
					btn.addEventListener('click', () => {
						if (hiddenInput) {
							hiddenInput.value = btn.getAttribute('data-value') || '';
						}
						if (label) {
							label.textContent = btn.textContent || '';
						}
						closeAllMenus();
						runFiltersWithoutJump();
					});
				});
			});

			document.addEventListener('click', (event) => {
				const target = event.target;
				if (!selectRoots.some((selectRoot) => selectRoot.contains(target))) {
					closeAllMenus();
				}
			});

			document.addEventListener('keydown', (event) => {
				if (event.key === 'Escape') {
					closeAllMenus();
				}
			});
		}

		runFiltersWithoutJump();
	};

	window.ArknightEndfieldCardsInit = initArknProductCards;
	initArknProductCards(document);
})();
