<?php
// name=steam-companion-extended/includes/template-functions.php
if (!defined('ABSPATH')) exit;

if (!function_exists('scx_get_listing_status')) {
    /**
     * Get listing status for a post.
     * Priority:
     * 1) WP post_status mapping (pending/publish/draft)
     * 2) Explicit plugin meta (under_review/approved/rejected) for custom states
     */
        function scx_get_listing_status($post_id) {
        $post_status = get_post_status($post_id);

        if ($post_status === 'publish') {
            return 'approved';
        }

        if ($post_status === 'pending') {
            return 'under_review';
        }

        if ($post_status === 'draft') {
            return 'rejected';
        }

		
        $status = get_post_meta($post_id, 'scx_listing_status', true);
        if (in_array($status, ['under_review', 'approved', 'rejected'], true)) {
            return $status;
        }

        return 'under_review';
    }
}

if (!function_exists('scx_render_product_card')) {
    /**
     * Render a product card for a given post_id.
     *
     * $args:
     *  - show_status (bool) show the listing status badge (for dashboard)
     *  - classes (string) additional classes
     */
    function scx_render_product_card($post_id, $args = []) {
        $args = wp_parse_args($args, [
            'show_status' => false,
            'classes'     => '',
        ]);

        // Basic post / permalink
        $post = get_post($post_id);
        if (!$post) return;

        $permalink = get_permalink($post_id);

        // Steam / metadata stored by plugin
        $steam_avatar = get_post_meta($post_id, 'scx_steam_avatar', true);
        $steam_name = get_post_meta($post_id, 'scx_steam_name', true) ?: get_the_title($post_id);
        $steam_level = get_post_meta($post_id, 'scx_steam_level', true);
		// Steam level class (1 - 200)
$level_class = 'scx-level-basic';

if (is_numeric($steam_level)) {
    $steam_level = intval($steam_level);

    if ($steam_level >= 11 && $steam_level <= 30) {
        $level_class = 'scx-level-bronze';
    } elseif ($steam_level >= 31 && $steam_level <= 60) {
        $level_class = 'scx-level-silver';
    } elseif ($steam_level >= 61 && $steam_level <= 100) {
        $level_class = 'scx-level-gold';
    } elseif ($steam_level >= 101) {
        $level_class = 'scx-level-platinum';
    }
}

        $steam_profile_url = get_post_meta($post_id, 'scx_steam_profile_url', true);
        $seller_user_id = (int) get_post_field('post_author', $post_id);
        $verified_badge = scx_get_verified_badge_html($seller_user_id, ['class' => 'scx-verified-badge-inline']);

        // Bans
        $communityBan = get_post_meta($post_id, 'scx_ban_community', true) === '1';
        $tradeBan = get_post_meta($post_id, 'scx_ban_trade', true) === '1';
        $gameBan = get_post_meta($post_id, 'scx_ban_game', true) === '1';
        $vacBan = get_post_meta($post_id, 'scx_ban_vac', true) === '1';

        $ban_texts = [];
        if ($gameBan) $ban_texts[] = 'Game Ban';
        if ($vacBan) $ban_texts[] = 'VAC Ban';
        if ($communityBan) $ban_texts[] = 'Community Ban';
        if ($tradeBan) $ban_texts[] = 'Trade/Market Ban';
        if (empty($ban_texts)) $ban_texts[] = 'Clean';
        $ban_display = implode(' · ', $ban_texts);

        // Stats
        $games_owned = get_post_meta($post_id, 'scx_games_owned', true);
        $games_json = get_post_meta($post_id, 'scx_games_library', true);
        $games = json_decode($games_json, true);
        if (!is_array($games)) $games = [];
        if ($games_owned === '') {
            $games_owned_display = count($games);
        } else {
            $games_owned_display = intval($games_owned);
        }

        $friends = intval(get_post_meta($post_id, 'scx_friends', true));
        $account_created = get_post_meta($post_id, 'scx_account_created', true);
        if (empty($account_created)) {
            $account_created = get_the_date('', $post_id);
        }

        $region = get_post_meta($post_id, 'scx_region', true);

        $account_price = get_post_meta($post_id, 'scx_account_price', true);
        $market_status = get_post_meta($post_id, 'scx_market_status', true);
        $main_email = get_post_meta($post_id, 'scx_main_email', true);

        // Fallback avatar: post thumbnail or plugin asset
        if (empty($steam_avatar)) {
            $thumb = get_the_post_thumbnail_url($post_id, 'full');
            if ($thumb) $steam_avatar = $thumb;
            else $steam_avatar = SCX_URL . 'assets/default-avatar.png'; // optional default (may be absent)
        }

        // Listing status (for dashboard)
        $listing_status = $args['show_status'] ? scx_get_listing_status($post_id) : '';

        // Classes
        $outer_classes = trim('scx-product-card ' . $args['classes']);

        // Begin output
        ?>
   <div class="<?php echo esc_attr($outer_classes); ?>" data-post-id="<?php echo intval($post_id); ?>">

    <?php if ($args['show_status']): 
        $status_label = 'در حال بررسی';
        $status_class = 'scx-status-review';
        if ($listing_status === 'approved') {
		$status_label = 'تایید شده';
        $status_class = 'scx-status-approved';
        }
		elseif ($listing_status === 'rejected') {
		$status_label = 'رد شده';
		$status_class = 'scx-status-rejected';
        }
    ?>
    <div class="scx-listing-status <?php echo esc_attr($status_class); ?>">
        <?php echo esc_html($status_label); ?>
    </div>
    <?php endif; ?>

    <div class="scx-product-card-inner">

        <div class="scx-product-left">
            <div class="scx-card-main">

                <!-- Avatar + Name + Profile -->
                <div class="scx-card-title-row">
                    <div class="scx-avatar-card-wrap">
    <div class="scx-card-avatar-card">
        <img src="<?php echo esc_url($steam_avatar); ?>" alt="<?php echo esc_attr($steam_name); ?>">
    </div>

    <?php if (!empty($steam_level)): ?>
        <div class="scx-steam-level <?php echo esc_attr($level_class); ?>">
    Lv. <?php echo esc_html($steam_level); ?>
</div>
    <?php endif; ?>
</div>
                    <div class="scx-card-title-info">
    <a href="<?php echo esc_url($permalink); ?>" class="scx-card-title" title="<?php echo esc_attr($steam_name); ?>">
        <span class="scx-card-title-text"><?php echo esc_html($steam_name); ?></span>
        <?php echo $verified_badge; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    </a>
    <?php if (!empty($steam_profile_url)): ?>
        <a class="scx-card-profile-link" href="<?php echo esc_url($steam_profile_url); ?>" target="_blank" rel="noopener noreferrer">Steam profile</a>
    <?php endif; ?>
</div>

                </div>

                <!-- Bans -->
                <div class="scx-card-bans">
                    <?php 
                    $ban_display_list = [];
                    if ($gameBan) $ban_display_list[] = '<span class="scx-ban-item-card scx-ban-red">Game Ban</span>';
                    if ($vacBan) $ban_display_list[] = '<span class="scx-ban-item-card scx-ban-red">VAC Ban</span>';
                    if ($communityBan) $ban_display_list[] = '<span class="scx-ban-item-card scx-ban-red">Community Ban</span>';
                    if ($tradeBan) $ban_display_list[] = '<span class="scx-ban-item-card scx-ban-red">Trade/Market Ban</span>';
                    if (empty($ban_display_list)) $ban_display_list[] = '<span class="scx-ban-item-card scx-ban-green">بدون بن</span>';
                    echo implode(' · ', $ban_display_list);
                    ?>
                </div>

                <!-- Stats -->
                <div class="scx-card-stats">
                    <span>🎮 <?php echo esc_html($games_owned_display); ?> games</span>
                    <span>👥 <?php echo esc_html($friends); ?> friends</span>
                    <span>📅 <?php echo esc_html($account_created); ?></span>
                    <?php if (!empty($region)): ?>
                        <span>🌍 <?php echo esc_html($region); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Right Side: Price + Meta + Actions -->
        <div class="scx-product-right">
            <div class="scx-product-price">
                <?php if ($account_price !== ''): ?>
                    <?php echo esc_html(number_format(floatval(str_replace([',',' '], '', $account_price)))); ?> تومان
                <?php else: ?>
                    —
                <?php endif; ?>
            </div>

            <!-- Market & Original Email -->
            <div class="scx-product-meta">
                <div>
                    <strong>مارکت استیم</strong>
                    <?php if ($market_status === 'active'): ?>
                        <span class="scx-meta-badge scx-meta-green">فعال</span>
                    <?php elseif ($market_status === 'inactive'): ?>
                        <span class="scx-meta-badge scx-meta-red">غیرفعال</span>
                    <?php else: ?>
                        <span class="scx-meta-badge">—</span>
                    <?php endif; ?>
                </div>
                <div>
                    <strong>ایمیل اوریجینال</strong>
                    <?php if ($main_email === 'yes'): ?>
                        <span class="scx-meta-badge scx-meta-green">هست</span>
                    <?php elseif ($main_email === 'no'): ?>
                        <span class="scx-meta-badge scx-meta-red">نیست</span>
                    <?php else: ?>
                        <span class="scx-meta-badge">—</span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Actions -->
            <div class="scx-product-actions">
                <a class="scx-btn-view" href="<?php echo esc_url($permalink); ?>">جزئیات بیشتر</a>
            </div>
        </div>

    </div>
</div>

        <?php
    }
}

/* ===========================
   Shortcode: scx_listings
   Usage: [scx_listings posts_per_page="12" show_status="1" author="current" market_status="active"]
   =========================== */

if (!function_exists('scx_listings_shortcode')) {
    function scx_get_filter_select_options($meta_key) {
        global $wpdb;

        $query = $wpdb->prepare(
            "SELECT DISTINCT pm.meta_value
            FROM {$wpdb->postmeta} pm
            INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
            WHERE pm.meta_key = %s
              AND pm.meta_value <> ''
              AND p.post_type = 'download'
              AND p.post_status = 'publish'
            ORDER BY pm.meta_value ASC",
            $meta_key
        );

        $results = $wpdb->get_col($query);
        return is_array($results) ? array_values(array_filter($results)) : [];
    }

    function scx_parse_numeric_filter($value) {
        $value = is_string($value) ? trim(str_replace([',', ' '], '', $value)) : $value;
        return (is_numeric($value) && $value !== '') ? floatval($value) : null;
    }

    function scx_resolve_shortcode_user_id($atts = []) {
        $atts = wp_parse_args($atts, [
            'user_id'  => 0,
            'steam_id' => '',
        ]);

        if (!empty($atts['user_id']) && is_numeric($atts['user_id'])) {
            return intval($atts['user_id']);
        }

        if (!empty($_GET['user_id']) && is_numeric($_GET['user_id'])) {
            return intval(wp_unslash($_GET['user_id']));
        }

        $steam_id_candidates = [];

        if (!empty($atts['steam_id'])) {
            $steam_id_candidates[] = sanitize_text_field($atts['steam_id']);
        }

        if (!empty($_GET['steam_id'])) {
            $steam_id_candidates[] = sanitize_text_field(wp_unslash($_GET['steam_id']));
        }

        if (!empty($_POST['steam_id'])) {
            $steam_id_candidates[] = sanitize_text_field(wp_unslash($_POST['steam_id']));
        }

        if (!empty($_REQUEST['steam_id'])) {
            $steam_id_candidates[] = sanitize_text_field(wp_unslash($_REQUEST['steam_id']));
        }

        $scp_query_steam_id = get_query_var('scp_steam_user');
        if (!empty($scp_query_steam_id)) {
            $steam_id_candidates[] = sanitize_text_field($scp_query_steam_id);
        }

        foreach ($steam_id_candidates as $steam_id_candidate) {
            if ($steam_id_candidate === '') {
                continue;
            }

            $matched_user = get_users([
                'number'     => 1,
                'fields'     => 'ids',
                'meta_query' => [
                    [
                        'key'   => 'steam_id',
                        'value' => $steam_id_candidate,
                    ],
                ],
            ]);

            if (!empty($matched_user[0])) {
                return intval($matched_user[0]);
            }
        }

        $queried = get_queried_object();
        if ($queried instanceof WP_User) {
            return intval($queried->ID);
        }

        if (isset($queried->ID) && get_post_type($queried->ID) === 'download') {
            return intval(get_post_field('post_author', $queried->ID));
        }

        return 0;
    }

    function scx_build_listings_query_args($filters = [], $atts = []) {
        $atts = wp_parse_args($atts, [
            'posts_per_page' => 12,
            'author'         => '',
            'market_status'  => '',
            'orderby'        => 'date',
            'order'          => 'DESC',
            'category'       => '',
        ]);

        $filters = wp_parse_args($filters, [
            'year'           => '',
            'region'         => '',
            'market_status'  => '',
            'main_email'     => '',
            'steam_level_min'=> '',
            'steam_level_max'=> '',
            'price_min'      => '',
            'price_max'      => '',
            'has_ban'        => '',
        ]);

        $args = [
            'post_type'      => 'download',
            'post_status'    => 'publish',
            'posts_per_page' => intval($atts['posts_per_page']),
            'orderby'        => sanitize_text_field($atts['orderby']),
            'order'          => sanitize_text_field($atts['order']),
        ];

        if (!empty($atts['author'])) {
            if ($atts['author'] === 'current' && is_user_logged_in()) {
                $args['author'] = get_current_user_id();
            } elseif (is_numeric($atts['author'])) {
                $args['author'] = intval($atts['author']);
            }
        }

		 $tax_query = [
            'relation' => 'AND',
            [
                'taxonomy' => 'download_category',
                'field'    => 'name',
                'terms'    => ['steam account'],
            ],
        ];

        if (!empty($atts['category'])) {
            $tax_query[] = [
                'taxonomy' => 'download_category',
                'field'    => 'slug',
                'terms'    => sanitize_text_field($atts['category']),
            ];
        }
		
		$args['tax_query'] = $tax_query;

        $meta_query = ['relation' => 'AND'];

        $market_status = $filters['market_status'] ?: $atts['market_status'];
        if ($market_status !== '') {
            $meta_query[] = [
                'key'     => 'scx_market_status',
                'value'   => sanitize_text_field($market_status),
                'compare' => '=',
            ];
        }

        if ($filters['year'] !== '') {
            $meta_query[] = [
                'key'     => 'scx_account_created',
                'value'   => sanitize_text_field($filters['year']),
                'compare' => '=',
            ];
        }

        if ($filters['region'] !== '') {
            $meta_query[] = [
                'key'     => 'scx_region',
                'value'   => sanitize_text_field($filters['region']),
                'compare' => '=',
            ];
        }

        if ($filters['main_email'] !== '') {
            $meta_query[] = [
                'key'     => 'scx_main_email',
                'value'   => sanitize_text_field($filters['main_email']),
                'compare' => '=',
            ];
        }

        $steam_level_min = scx_parse_numeric_filter($filters['steam_level_min']);
        $steam_level_max = scx_parse_numeric_filter($filters['steam_level_max']);
        if ($steam_level_min !== null || $steam_level_max !== null) {
            if ($steam_level_min !== null && $steam_level_max !== null) {
                $meta_query[] = [
                    'key'     => 'scx_steam_level',
                    'value'   => [$steam_level_min, $steam_level_max],
                    'type'    => 'NUMERIC',
                    'compare' => 'BETWEEN',
                ];
            } elseif ($steam_level_min !== null) {
                $meta_query[] = [
                    'key'     => 'scx_steam_level',
                    'value'   => $steam_level_min,
                    'type'    => 'NUMERIC',
                    'compare' => '>=',
                ];
            } else {
                $meta_query[] = [
                    'key'     => 'scx_steam_level',
                    'value'   => $steam_level_max,
                    'type'    => 'NUMERIC',
                    'compare' => '<=',
                ];
            }
        }

        $price_min = scx_parse_numeric_filter($filters['price_min']);
        $price_max = scx_parse_numeric_filter($filters['price_max']);
        if ($price_min !== null || $price_max !== null) {
            if ($price_min !== null && $price_max !== null) {
                $meta_query[] = [
                    'key'     => 'scx_account_price',
                    'value'   => [$price_min, $price_max],
                    'type'    => 'NUMERIC',
                    'compare' => 'BETWEEN',
                ];
            } elseif ($price_min !== null) {
                $meta_query[] = [
                    'key'     => 'scx_account_price',
                    'value'   => $price_min,
                    'type'    => 'NUMERIC',
                    'compare' => '>=',
                ];
            } else {
                $meta_query[] = [
                    'key'     => 'scx_account_price',
                    'value'   => $price_max,
                    'type'    => 'NUMERIC',
                    'compare' => '<=',
                ];
            }
        }

        if ($filters['has_ban'] === '1') {
            $meta_query[] = [
                'relation' => 'OR',
                ['key' => 'scx_ban_community', 'value' => '1', 'compare' => '='],
                ['key' => 'scx_ban_trade', 'value' => '1', 'compare' => '='],
                ['key' => 'scx_ban_game', 'value' => '1', 'compare' => '='],
                ['key' => 'scx_ban_vac', 'value' => '1', 'compare' => '='],
            ];
        }

        if (count($meta_query) > 1) {
            $args['meta_query'] = $meta_query;
        }

        return $args;
    }

    function scx_render_listings_html($query, $show_status = false) {
        if (!$query->have_posts()) {
            return '<div class="scx-listings-empty"><p>هیچ آگهی‌ای یافت نشد.</p></div>';
        }

        ob_start();
        echo '<div class="scx-listings-grid">';
        while ($query->have_posts()) {
            $query->the_post();
            scx_render_product_card(get_the_ID(), [
                'show_status' => $show_status,
                'classes'     => 'scx-listing-card',
            ]);
        }
        echo '</div>';
        wp_reset_postdata();

        return ob_get_clean();
    }

    function scx_render_custom_select($name, $label, $placeholder, $options) {
        ob_start();
        ?>
        <div class="scx-filter-field">
            <label><?php echo esc_html($label); ?></label>
            <div class="scx-select scx-filter-select" data-name="<?php echo esc_attr($name); ?>">
                <button type="button" class="scx-select-trigger"><?php echo esc_html($placeholder); ?></button>
                <div class="scx-select-options">
                    <button type="button" class="scx-option" data-value=""><?php echo esc_html($placeholder); ?></button>
                    <?php foreach ($options as $value => $text): ?>
                        <button type="button" class="scx-option" data-value="<?php echo esc_attr($value); ?>"><?php echo esc_html($text); ?></button>
                    <?php endforeach; ?>
                </div>
                <input type="hidden" name="<?php echo esc_attr($name); ?>" value="">
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    function scx_render_listings_filters($instance_id) {
        $years_raw = scx_get_filter_select_options('scx_account_created');
        $regions_raw = scx_get_filter_select_options('scx_region');

        $years = [];
        foreach ($years_raw as $year) {
            $years[$year] = $year;
        }

        $regions = [];
        foreach ($regions_raw as $region) {
            $regions[$region] = $region;
        }

        ob_start();
        ?>
        <form class="scx-listings-filter" data-instance="<?php echo esc_attr($instance_id); ?>">
            <div class="scx-filter-row scx-filter-row-top">
                <?php echo scx_render_custom_select('year', 'سال ساخت', 'همه سال‌ها', $years); ?>
                <?php echo scx_render_custom_select('region', 'ریجن', 'همه ریجن‌ها', $regions); ?>
                <?php echo scx_render_custom_select('main_email', 'ایمیل اوریجینال', 'همه وضعیت‌ها', ['yes' => 'دارد', 'no' => 'ندارد']); ?>
                <?php echo scx_render_custom_select('market_status', 'مارکت استیم', 'همه وضعیت‌ها', ['active' => 'فعال', 'inactive' => 'غیرفعال']); ?>
            </div>

            <div class="scx-filter-row scx-filter-row-bottom">
                <div class="scx-filter-field">
                    <label>استیم لول (عددی)</label>
                    <div class="scx-filter-range">
                        <input type="number" name="steam_level_min" min="0" placeholder="از">
                        <span>تا</span>
                        <input type="number" name="steam_level_max" min="0" placeholder="تا">
                    </div>
                </div>

                <div class="scx-filter-field">
                    <label>قیمت (تومان)</label>
                    <div class="scx-filter-range">
                        <input type="number" name="price_min" min="0" step="1000" placeholder="مثال: 1000000">
                        <span>تا</span>
                        <input type="number" name="price_max" min="0" step="1000" placeholder="مثال: 3000000">
                    </div>
                </div>

                <div class="scx-filter-field">
                    <label>وضعیت بن</label>
                    <label class="scx-filter-checkbox">
                        <input type="checkbox" name="has_ban" value="1">
                        <span>فقط اکانت‌های دارای هر نوع بن نمایش داده شود</span>
                    </label>
                </div>
            </div>

            <div class="scx-filter-actions">
                <button type="submit" class="scx-btn-filter">فیلتر کردن</button>
                <button type="button" class="scx-btn-reset">پاک کردن فیلترها</button>
            </div>
        </form>
        <?php

        return ob_get_clean();
    }

    function scx_ajax_filter_listings() {
        check_ajax_referer('scx_listing_filter', 'nonce');

        $atts = isset($_POST['atts']) && is_array($_POST['atts']) ? wp_unslash($_POST['atts']) : [];
        $filters = isset($_POST['filters']) && is_array($_POST['filters']) ? wp_unslash($_POST['filters']) : [];
        $show_status = !empty($atts['show_status']);

        $args = scx_build_listings_query_args($filters, $atts);
        $query = new WP_Query($args);
        $html = scx_render_listings_html($query, $show_status);

        wp_send_json_success(['html' => $html]);
    }
    add_action('wp_ajax_scx_filter_listings', 'scx_ajax_filter_listings');
    add_action('wp_ajax_nopriv_scx_filter_listings', 'scx_ajax_filter_listings');

    function scx_listings_shortcode($atts = []) {
        $atts = shortcode_atts([
            'posts_per_page' => 12,
            'author'         => '',      // numeric user ID or "current"
            'show_status'    => 0,
            'market_status'  => '',      // active / inactive
            'orderby'        => 'date',
            'order'          => 'DESC',
			'category'       => '',      // optional additional download_category term slug
            'show_filters'   => 1,
        ], $atts, 'scx_listings');

        $query = new WP_Query(scx_build_listings_query_args([], $atts));
        $show_status = boolval(intval($atts['show_status']));
        $instance_id = uniqid('scx-listing-', false);

        ob_start();
        $frontend_atts = [
            'posts_per_page' => intval($atts['posts_per_page']),
            'author'         => sanitize_text_field($atts['author']),
            'show_status'    => intval($atts['show_status']),
            'market_status'  => sanitize_text_field($atts['market_status']),
            'orderby'        => sanitize_text_field($atts['orderby']),
            'order'          => sanitize_text_field($atts['order']),
            'category'       => sanitize_text_field($atts['category']),
        ];

        echo '<div class="scx-listings-wrap" id="' . esc_attr($instance_id) . '" data-atts="' . esc_attr(wp_json_encode($frontend_atts)) . '">';

        if (boolval(intval($atts['show_filters']))) {
            echo scx_render_listings_filters($instance_id);
        }

        echo '<div class="scx-listings-results">';
        echo scx_render_listings_html($query, $show_status);
        echo '</div>';
        echo '</div>';

        wp_enqueue_script('scx-dota');
        wp_localize_script('scx-dota', 'scx_listing_filter', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('scx_listing_filter'),
        ]);

        return ob_get_clean();
    }
    add_shortcode('scx_listings', 'scx_listings_shortcode');

    function scx_user_store_listings_shortcode($atts = []) {
        $atts = shortcode_atts([
            'user_id'        => 0,
            'steam_id'       => '',
            'posts_per_page' => 12,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'show_filters'   => 0,
            'category'       => '',
        ], $atts, 'scx_user_store_listings');

        $target_user_id = scx_resolve_shortcode_user_id($atts);
        if (!$target_user_id || !get_user_by('id', $target_user_id)) {
            return '<div class="scx-listings-empty"><p>فروشنده معتبر یافت نشد.</p></div>';
        }

        $scx_listings_atts = [
            'posts_per_page' => intval($atts['posts_per_page']),
            'author'         => $target_user_id,
            'show_status'    => 0,
            'market_status'  => '',
            'orderby'        => sanitize_text_field($atts['orderby']),
            'order'          => sanitize_text_field($atts['order']),
            'category'       => sanitize_text_field($atts['category']),
            'show_filters'   => intval($atts['show_filters']),
        ];

        return scx_listings_shortcode($scx_listings_atts);
    }
    add_shortcode('scx_user_store_listings', 'scx_user_store_listings_shortcode');
}
