<?php
if (!defined('ABSPATH')) exit;

if (!function_exists('scx_steam_accounts_slider_shortcode')) {
    /**
     * Shortcode: [scx_steam_accounts_slider]
     * Shows latest Steam account products as a 3-column horizontal slider.
     */
    function scx_steam_accounts_slider_shortcode($atts = []) {
        $atts = shortcode_atts([
            'title'           => 'آکانت های Steam',
            'button_text'     => 'مشاهده همه',
            'button_url'      => 'https://gamebani.ir/buy-steam-account/',
            'category'        => 'steam-account',
            'posts_per_page'  => 12,
            'orderby'         => 'date',
            'order'           => 'DESC',
        ], $atts, 'scx_steam_accounts_slider');

        wp_enqueue_style(
            'scx-steam-slider',
            SCX_URL . 'assets/scx-steam-slider.css',
            ['scx-product-card'],
            '1.0.0'
        );

        wp_enqueue_script(
            'scx-steam-slider',
            SCX_URL . 'assets/scx-steam-slider.js',
            [],
            '1.0.0',
            true
        );

        $query_args = [
            'post_type'           => 'download',
            'post_status'         => 'publish',
            'posts_per_page'      => max(1, intval($atts['posts_per_page'])),
            'orderby'             => sanitize_text_field($atts['orderby']),
            'order'               => sanitize_text_field($atts['order']),
            'ignore_sticky_posts' => true,
        ];

        $category_slug = sanitize_title($atts['category']);
        if (!empty($category_slug)) {
            $query_args['tax_query'] = [
                [
                    'taxonomy' => 'download_category',
                    'field'    => 'slug',
                    'terms'    => $category_slug,
                ],
            ];
        }

        $query = new WP_Query($query_args);
        $instance_id = uniqid('scx-steam-slider-', false);

        ob_start();
        ?>
        <section class="scx-steam-slider-section" id="<?php echo esc_attr($instance_id); ?>" dir="rtl">
            <div class="scx-steam-slider-head">
                <div class="scx-steam-slider-head-inline">
                    <h3 class="scx-steam-slider-title"><?php echo esc_html($atts['title']); ?></h3>
                    <a class="scx-steam-slider-link" href="<?php echo esc_url($atts['button_url']); ?>"><?php echo esc_html($atts['button_text']); ?></a>
                </div>
            </div>

            <?php if ($query->have_posts()): ?>
                <div class="scx-steam-slider-wrap" data-scx-slider>
                    <button type="button" class="scx-steam-slider-nav prev" data-scx-prev aria-label="قبلی">‹</button>
                    <div class="scx-steam-slider-track" data-scx-track>
                        <?php while ($query->have_posts()): $query->the_post(); ?>
                            <div class="scx-steam-slide">
                                <?php scx_render_product_card(get_the_ID(), ['classes' => 'scx-steam-slider-card']); ?>
                            </div>
                        <?php endwhile; wp_reset_postdata(); ?>
                    </div>
                    <button type="button" class="scx-steam-slider-nav next" data-scx-next aria-label="بعدی">›</button>
                </div>
            <?php else: ?>
                <div class="scx-listings-empty"><p>محصولی در این دسته‌بندی پیدا نشد.</p></div>
            <?php endif; ?>
        </section>
        <?php

        return ob_get_clean();
    }

    add_shortcode('scx_steam_accounts_slider', 'scx_steam_accounts_slider_shortcode');
}
