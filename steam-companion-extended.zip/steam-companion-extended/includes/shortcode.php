<?php
if (!defined('ABSPATH')) exit;


add_shortcode('steam_extended_profile',function(){

    if(!is_user_logged_in()) return '<p>لطفا وارد شوید</p>';

    $user_id=get_current_user_id();
    $steam_id=get_user_meta($user_id,'steam_id',true);

   if(!$steam_id) {
    return '
    <div class="scx-steam-not-connected">
        <div class="scx-steam-notice-title">آکانت استیم متصل نیست.</div>
        <div class="scx-steam-notice-desc">برای مشاهده پروفایل و اطلاعات آکانت استیم، ابتدا استیم خود را متصل کنید</div>
        <div class="scx-steam-login-btn">
            '. do_shortcode("[steam_login_button_simple]") .'
        </div>
    </div>
    ';
}

    $profile=scx_get_player_summary($steam_id);
    if(!$profile) return '<p>خطا در دریافت اطلاعات Steam</p>';

    // Fetch visibility live (no caching) so status is always current
    $visibility = 'Unknown';
    if (defined('SCX_API_KEY') && SCX_API_KEY) {
        $vis_url = "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/?key=" . SCX_API_KEY . "&steamids={$steam_id}";
        $vis_resp = wp_remote_get($vis_url, ['timeout' => 15]);
        if (!is_wp_error($vis_resp)) {
            $vis_body = json_decode(wp_remote_retrieve_body($vis_resp), true);
            $vis_player = $vis_body['response']['players'][0] ?? null;
            if ($vis_player && isset($vis_player['communityvisibilitystate'])) {
                // Steam communityvisibilitystate values:
                // 1 = Private, 2 = Friends Only, 3 = Public (treat 3 as Public, others as Private)
                $state = intval($vis_player['communityvisibilitystate']);
                $visibility = ($state === 3) ? 'آکانت شما Public است' : 'آکانت شما Private است';
            }
        }
    }

    $level=scx_get_steam_level($steam_id);
    $bans=scx_get_bans($steam_id);
    $friends=scx_get_friends_count($steam_id);
    $games=scx_get_owned_games($steam_id);
	$creation_year = scx_get_account_creation_year($profile);
	$region = scx_get_region($profile);

    /* BAN LOGIC */

    $communityBan=!empty($bans['CommunityBanned']);
    $vacBan=!empty($bans['VACBanned']);
    $gameBan=!empty($bans['NumberOfGameBans']);
    $tradeBan=(($bans['EconomyBan'] ?? 'none') !== 'none');

    $anyBan=$communityBan || $vacBan || $gameBan || $tradeBan;

    ob_start();
?>

<div class="scx-wrapper">

  <!-- HEADER -->
<div class="scx-header-card">

    <!-- LEFT SIDE: AVATAR + NAME + LEVEL -->
    <div class="scx-header-left">
        <div class="scx-avatar-wrap">
            <img src="<?=esc_url($profile['avatarfull'])?>">
        </div>

        <div class="scx-header-info">
            <h2><?=esc_html($profile['personaname'])?></h2>

            <div class="scx-badges">
                <span class="scx-badge pro">PRO</span>
                <span class="scx-steam-level">Lv. <?=intval($level)?></span>
            </div>

            <a href="<?=esc_url($profile['profileurl'])?>" target="_blank" class="scx-profile-link">
                Steam Profile
            </a>
        </div>
    </div>

    <!-- RIGHT SIDE: VISIBILITY -->
    <?php
// لینک تنظیمات پروفایل Steam کاربر
$visibility_url = "https://steamcommunity.com/profiles/{$steam_id}/edit/settings";
?>
<div class="scx-header-right">
    <a href="<?= esc_url($visibility_url) ?>" target="_blank" class="scx-visibility-badge <?= ($visibility === 'آکانت شما Public است') ? 'public' : 'private' ?>">
        <?= esc_html($visibility) ?>
    </a>
</div>


</div>



    <!-- STATS -->
<div class="scx-stats-grid">

    <!-- BAN MASTER BOX -->
    <div class="scx-ban-box <?=$anyBan?'banned':'clean'?>">

        <div class="scx-ban-status">
            STATUS : <?=$anyBan?'BANNED':'CLEAN'?>
        </div>

        <div class="scx-ban-grid">

            <div class="scx-ban-item <?=$communityBan?'bad':'good'?>">
                Community Ban
            </div>

            <div class="scx-ban-item <?=$tradeBan?'bad':'good'?>">
                Trade / Market Ban
            </div>

            <div class="scx-ban-item <?=$gameBan?'bad':'good'?>">
                Game Ban
            </div>

            <div class="scx-ban-item <?=$vacBan?'bad':'good'?>">
                VAC Ban
            </div>

        </div>

    </div>

    <!-- RIGHT STATS -->
    <div class="scx-stat blue">
        <span>Games Owned</span>
        <strong><?=count($games)?></strong>
    </div>

    <div class="scx-stat purple">
        <span>Friends</span>
        <strong><?=intval($friends)?></strong>
    </div>

    <div class="scx-stat teal">
        <span>Account Created</span>
        <strong><?=esc_html($creation_year ?? '--')?></strong>
    </div>

    <div class="scx-stat gold">
        <span>Region</span>
        <strong><?=esc_html($region ?? '--')?></strong>
    </div>

</div>


    <!-- GAMES -->
    <?php
    $games_total_usd = 0;
    $games_view_data = [];

    foreach ($games as $game) {
        $playtime_hours = floor(($game['playtime_forever'] ?? 0) / 60);
        $store = scx_get_game_store_info($game['appid']);

        $is_free = !empty($store['is_free']);
        $price = null;

        if (!$is_free && !empty($store['price_overview'])) {
            $price = $store['price_overview']['final_formatted'];
        }

        if (!$is_free && !empty($store['price_overview']['final'])) {
            $games_total_usd += floatval($store['price_overview']['final']) / 100;
        }

        $games_view_data[] = [
            'appid' => $game['appid'],
            'name' => $game['name'],
            'playtime_hours' => $playtime_hours,
            'is_free' => $is_free,
            'price' => $price,
        ];
    }

    ?>
    <h3 class="scx-section-title">
        <span>Game Library</span>
        <span class="scx-total-price">
            <span class="scx-total-price-value">Total: $<?=number_format($games_total_usd, 2)?></span>
            <span class="scx-total-price-tooltip">جمع قیمت بازی های آکانت استیم</span>
        </span>
    </h3>

<div class="scx-games-grid">
<?php foreach($games_view_data as $game): ?>
    <div class="scx-game-card">

        <img src="https://cdn.cloudflare.steamstatic.com/steam/apps/<?=$game['appid']?>/header.jpg">

        <div class="scx-game-info">
            <div class="scx-game-title"><?=esc_html($game['name'])?></div>
            <div class="scx-game-meta">
                <span class="scx-game-hours"><?=$game['playtime_hours']?> ساعت </span>
                <?php if($game['is_free']): ?>
                    <span class="scx-game-free">Free</span>
                <?php elseif($game['price']): ?>
                    <span class="scx-game-price"><?=$game['price']?></span>
                <?php else: ?>
                    <span class="scx-game-price">Paid</span>
                <?php endif; ?>
            </div>
        </div>

    </div>
<?php endforeach; ?>
</div>
<!-- ================= DOTA 2 PROFESSIONAL CARD ================= -->

<div class="scx-dota-card">

    <div class="scx-dota-head">
        <span>فرم بازی Dota 2</span>
        <span class="scx-dota-toggle">+</span>
    </div>

    <div class="scx-dota-content">
<?php
$medals = [
    'Herald'    => [1,2,3,4,5],
    'Guardian'  => [1,2,3,4,5],
    'Crusader'  => [1,2,3,4,5],
    'Archon'    => [1,2,3,4,5],
    'Legend'    => [1,2,3,4,5],
    'Ancient'   => [1,2,3,4,5],
    'Divine'    => [1,2,3,4,5],
    'Immortal'  => [1],
    'Immortal Top'  => [100, 10],
];
?>

<div class="scx-medal-card">
    <div class="scx-card-content">
        <div class="scx-medals">
            <?php foreach ($medals as $name => $stars): ?>
                <?php foreach ($stars as $star): ?>
                    <div class="scx-medal <?php 
echo strtolower(str_replace(' ', '-', $name)); 
echo (stripos($name, 'immortal') !== false) ? ' immortal' : ''; 
?>" data-value="<?php echo esc_attr("$name-$star"); ?>">

                        <img src="<?php echo esc_url( SCX_URL . "assets/medals/". lcfirst(str_replace(' ', '-', $name)) . "-$star.png" ); ?>" alt="<?php echo esc_attr("$name $star"); ?>">
                        <!-- اسم مدال زیر عکس -->
                       <span class="scx-medal-title">
    <?=esc_html($name . ' ' . $star)?>
</span>

                    </div>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
        <input type="hidden" name="dota_medal" value="">
    </div>
</div>


        <div class="scx-dota-grid">

         
            <!-- MMR -->
            <div class="scx-dota-field blue">
                <label>MMR</label>
                <div class="scx-input">
                    <input type="number" name="dota_mmr" placeholder="4320">
                </div>
            </div>

            <!-- BEHAVIOR -->
            <div class="scx-dota-field teal">
                <label>Behavior Score</label>
                <div class="scx-input">
                    <input type="number" name="dota_behavior" placeholder="9400">
                </div>
            </div>

            <!-- LEVEL -->
            <div class="scx-dota-field gold">
                <label>Dota Level</label>
                <div class="scx-input">
                    <input type="number" name="dota_level" placeholder="57">
                </div>
            </div>

			 <!-- SHARDS -->
  			  <div class="scx-dota-field shards">
    		    <label>Shards</label>
    		    <div class="scx-input">
            <input type="number" name="dota_shards" placeholder="12500">
        </div>
    </div>

</div>

        </div>

    </div>

	<!-- ================= CS2 PROFESSIONAL CARD ================= -->
<?php
$cs2_ranks = [
    'Silver I',
    'Silver II',
    'Silver III',
    'Silver IV',
    'Silver Elite',
    'Silver Elite Master',
    'Gold Nova I',
    'Gold Nova II',
    'Gold Nova III',
    'Gold Nova Master',
    'Master Guardian I',
    'Master Guardian II',
    'Master Guardian Elite',
    'Distinguished Master Guardian',
    'Legendary Eagle',
    'Legendary Eagle Master',
    'Supreme Master First Class',
    'Global Elite',
];
?>

<div class="scx-cs2-card">
    <div class="scx-cs2-head">
        <span>فرم بازی Cs2</span>
        <span class="scx-cs2-toggle">+</span>
    </div>

    <div class="scx-cs2-content">
        <div class="scx-cs2-rank-card scx-medal-card" data-input="cs2_rank">
            <div class="scx-card-content">
                <div class="scx-medals scx-cs2-ranks">
                    <?php foreach ($cs2_ranks as $rank_name):
                        $tier_class = 'tier-default';
                        if (stripos($rank_name, 'Silver') === 0) {
                            $tier_class = 'tier-silver';
                        } elseif (stripos($rank_name, 'Gold Nova') === 0) {
                            $tier_class = 'tier-gold';
                        } elseif (stripos($rank_name, 'Master Guardian') === 0 || stripos($rank_name, 'Distinguished Master Guardian') === 0) {
                            $tier_class = 'tier-guardian';
                        } elseif (stripos($rank_name, 'Legendary Eagle') === 0) {
                            $tier_class = 'tier-eagle';
                        } elseif (stripos($rank_name, 'Supreme') === 0) {
                            $tier_class = 'tier-supreme';
                        } elseif (stripos($rank_name, 'Global') === 0) {
                            $tier_class = 'tier-global';
                        }
                    ?>
                        <div class="scx-medal scx-cs2-rank <?= esc_attr($tier_class) ?>" data-value="<?= esc_attr($rank_name) ?>">
                            <span class="scx-medal-title"><?= esc_html($rank_name) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <input type="hidden" name="cs2_rank" value="">
            </div>
        </div>

        <div class="scx-cs2-grid">
            <div class="scx-cs2-field">
                <label>نوع اکانت</label>
                <div class="scx-select scx-form-select">
                    <div class="scx-select-trigger">انتخاب</div>
                    <div class="scx-select-options">
                        <div class="scx-option" data-value="main_account">اکانت شخصی (Main Account)</div>
                        <div class="scx-option" data-value="smurf">اسمورف (Smurf)</div>
                        <div class="scx-option" data-value="leveled_up">لول‌اپ شده</div>
                        <div class="scx-option" data-value="fresh">تازه ساخته شده</div>
                        <div class="scx-option" data-value="skins_only">فقط برای اسکین</div>
                        <div class="scx-option" data-value="legacy">اکانت قدیمی (Legacy)</div>
                    </div>
                    <input type="hidden" name="cs2_account_type" value="">
                </div>
            </div>

            <div class="scx-cs2-field">
                <label>وضعیت پرایم</label>
                <div class="scx-select scx-form-select">
                    <div class="scx-select-trigger">انتخاب</div>
                    <div class="scx-select-options">
                        <div class="scx-option" data-value="active_prime">دارد (Active Prime)</div>
                        <div class="scx-option" data-value="no_prime">ندارد</div>
                    </div>
                    <input type="hidden" name="cs2_prime_status" value="">
                </div>
            </div>

            <div class="scx-cs2-field">
                <label>لول بازی</label>
                <div class="scx-input">
                    <input type="number" name="cs2_level" min="1" max="999" placeholder="مثال: 180">
                </div>
            </div>

            <div class="scx-cs2-field scx-cs2-field-full">
                <label>Service Medal</label>
                <div class="scx-input">
                    <input type="text" name="cs2_service_medal" placeholder="مثال: 2024 Service Medal - Purple">
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ================= پایان فرم Cs2 ================= -->

	<!-- ================= APEX LEGENDS PROFESSIONAL CARD ================= -->
<?php
$apex_ranks = [
    'Bronze1','Bronze2','Bronze3','Bronze4',
    'Silver1','Silver2','Silver3','Silver4',
    'Gold1','Gold2','Gold3','Gold4',
    'Platinum1','Platinum2','Platinum3','Platinum4',
    'Diamond1','Diamond2','Diamond3','Diamond4',
    'Master','ApexPredator',
];

$apex_legend_skins = [
    'Bangalore' => ['The Enforcer Bangalore','Officer Williams Bangalore','The Spacewalker Bangalore','Apex Overdrive Bangalore','Viceroy Bangalore','Full Metal Jacket Bangalore','Killer B Bangalore','Outland Warrior Bangalore','La Catrina Bangalore','Cherry Bomb Bangalore','Stay Frosty Bangalore','Killing Machine Bangalore','Mint Condition Bangalore','Sky Marshal Bangalore','Soldado de la Muerta Bangalore','Dressed To Impress Bangalore','Radical Action Bangalore','Crimson Queen Bangalore','Decorated Bangalore','Super Soldier Bangalore','Apex Commander Bangalore','High Visibility Bangalore','Solar Soldier Bangalore','MIL Bangalore','Violet Veteran Bangalore','Frozen Loyalty Bangalore','V-SPEC Bangalore','Cosmic Enforcer Bangalore','Cyber Warfare Bangalore','Cybernetic Soldier Bangalore','Soul Keeper Bangalore','Divine Legion Bangalore'],
    'Fuse' => ['Man-O-War Fuse','Dread Captain Fuse','Natural Born Daredevil Fuse','Old Gold Fuse','Broseidon Fuse','Real Steel Fuse','Boared to Death Fuse','Scallywag Fuse','Cybernetic Payload Fuse','Silver Fox Fuse','Sir Fitzroy Fuse','Animal Instinct Fuse','Bounty Hunter Fuse','Father Fitzmas Fuse','Down Umber Fuse','Artillery Armsman Fuse','License to Chill Fuse','Golden Grenadier Fuse','Professor Fitzroy Fuse','Pharaoh s Guardian Fuse'],
    'Ash' => ['Fallen Angel Ash','Chaotic Emerald Ash','Eagle-Eyed Ash','Mercenary Mystique Ash','Denizen of the Deep Ash','Chain of Command Ash','Synthetic Huntress Ash','Solar Consequence Ash','Existential Threat Ash','Inner Demon Ash','Imperial Assailant Ash','Opalescent Serpent Ash','Biotechnic Ash','Opulent Instigator Ash','Pierless Ash','Eternal Reign Ash','Project 19 Ash','Stinger Ash','Curse Keeper Ash'],
    'Maggie' => ['Mob Boss Maggie','Above The Law Maggie','Steamed Maggie','Mad Metal Maggie','Maori Warrior Maggie','Blood and Plunder Maggie','Outside The Law Maggie','Non-State Actor Maggie','Necro-Smasher Maggie','Furious Fatale Maggie','Outlawed Tech Maggie'],
    'Ballistic' => ['Earl Grey Ballistic','Mr Manners Ballistic','Neon Sunset Ballistic','Vice Grip Ballistic','General Destruction Ballistic','Bionic Brink Ballistic','Sleek Suave Ballistic'],
    'Pathfinder' => ['Angel City Pacer Pathfinder','Quicksilver Pathfinder','Model P Pathfinder','The Aviator Pathfinder','Bad Bot Pathfinder','Omega Point Pathfinder','Bot of Gold Pathfinder','Green Machine Pathfinder','War Machine Pathfinder','Iced Out Pathfinder','Joyfinder Pathfinder','SRVN MRVN Pathfinder','Pole Position Pathfinder','Plastic Fantastic Pathfinder','Waveracer Pathfinder','Full Metal Robot Pathfinder','Full Throttle Pathfinder','Memoir Noir Pathfinder','Friendly Fire Pathfinder','War Path Pathfinder','PATH Pathfinder','The Burgundy Knight Pathfinder','Mechameleon Pathfinder','Down Right Fierce Pathfinder','Elegant Mechanics Pathfinder','Deep Sixed Pathfinder','Untouchable Pathfinder','Search and Destroy Pathfinder','System Takeover Pathfinder','Dragon Warrior Pathfinder','Surround Sound Pathfinder','MechaMRVN Pathfinder','Gilded Sentinel Pathfinder','Pathogen Pathfinder','Wrong Path Pathfinder'],
    'Wraith' => ['Apex Voidshifter Wraith','Acid Wraith Wraith','7th Heaven Skirmisher Wraith','The Liberator Wraith','Vengeance Seeker Wraith','Quarantine 722 Wraith','Void Specialist Wraith','Quantum Collision Wraith','Airship Assassin Wraith','Flashpoint Wraith','Night Terror Wraith','Protector of the Void Wraith','Voidwalker Wraith','Mistress of Evil Wraith','Final Sunset Wraith','Perfect Soldier Wraith','Voices from the Past Wraith','Depths of the Void Wraith','Marble Goddess Wraith','Void Prowler Wraith','Emerald Enchantress Wraith','High Class Wraith','Risen Queen Wraith','Phasewalker Wraith','Hellcat Wraith',"Queens Guard Wraith","Demons Whisper Wraith",'Neon Spectre Wraith','Ringside Wraith','Wave Shift Wraith','Eternal Life Wraith','Demon Within Wraith','Rift Stalker Wraith','Veteran Voyager Wraith','Cosmic Phaser Wraith','Ancient of the Void Wraith','Phantom Phaser Wraith','Dark Apparition Wraith','Punk Phaser Wraith',"Voids Vassal Wraith",'Voided Warranty Wraith','Underworld Guardian Wraith','Festive Presence Wraith','Street Smart Wraith','Fast Fashion Wraith','Shadow Lurker Wraith'],
    'Octane' => ['Apex Riptide Octane','Touch of Style Octane','El Diablo Octane','Speed Demon Octane','The Victory Lap Octane','Gold Rush Octane','Sea Legs Octane','Red Shift Octane','Extreme Measures Octane','Jade Tiger Octane','Laughing Fool Octane','Dasher Octane','Clocktane Octane','Surplus Acceleration Octane','Arachnoid Rush Octane','XL-R8 Octane','Holeshot Hotshot Octane','Sonic Boom Octane','Fast Fashion Octane','El Tigre Octane',"Onis Shadow Octane",'Wild Speed Octane','Peak Performance Octane','Overdrive Octane','Riding Dirty Octane','Die Tired Octane','Steampunk Speedster Octane','Run the Streets Octane','Lucky Rabbit Octane','Biohazard Octane','Cerulean Centurion Octane','Fiendish Filigree Octane','Hothead Octane','Net Runner Octane','Heist Fashion Octane','Jump Scare Octane','Godly Speed Octane'],
    'Revenant' => ['Apex Nightmare Revenant','Shadow on the Sun Revenant','Bird of Prey Revenant','Unholy Beast Revenant','False Idol Revenant','Necro Nightmare Revenant','Revelations Revenant','The Afterlife Revenant','Relic of Death Revenant','Deathproof Revenant','Forged Knight Revenant','Frost Ancient Revenant','Sacred Divinity Revenant','Blood Ritual Revenant','A Gaze Eternal Revenant','Synthetic Shinobi Revenant','Seeing Red Revenant','Bleached Bone Revenant','Predatory Instinct Revenant','Ra Fury Revenant','Burial at Sea Revenant','No Chill Revenant','Necromancer Revenant','Deadly Teddy Revenant','Mail Order Monster Revenant','Deadly Relic Revenant','Soulless Sentry Revenant','Former Glory Revenant','Night Phoenix Revenant','Penumbra Revenant'],
    'Horizon' => ['Solaris Horizon','Terra Nova Horizon','Dark Matter Horizon','Golden Boson Horizon','Overfloater Horizon','Neon Stardust Horizon','Supermassive Horizon','Galactic Guardian Horizon','Biotic Luminary Horizon','Brave Hero Horizon','Jewel of Olympus Horizon','Rising Storm Horizon','Atom Heart Mother Horizon','Brood Mother Horizon','Phoenix Rising Horizon','Biophysic Horizon','Singularity Specialist Horizon','Deep Space Scientist Horizon','Lethal Lass Horizon','Brood Anomaly Horizon','Spectral Slayer Horizon','Player Three Horizon'],
    'Alter' => ['Crimson Dynasty Alter','Fashion Fatale Alter','Final Bow Alter','Moonlit Menace Alter','Final Laugh Alter','Coffin Stuffer Alter','End Play Alter','Dark Preserver Alter'],
    'Bloodhound' => ['The Plague Doctor Bloodhound','The Runekeeper Bloodhound','Royal Guard Bloodhound','Imperial Warrior Bloodhound','Hunter Within Bloodhound','Great Winter Bloodhound',"Ravens Shadow Bloodhound",'The Centurion Bloodhound','Protector of the Patch Bloodhound','The Intimidator Bloodhound','Wandering Warrior Bloodhound','Young Blood Bloodhound','Wise Warrior Bloodhound','Radiant Stalker Bloodhound','Road Warrior Bloodhound','Wicked Harvest Bloodhound','Dangerous Game Bloodhound','Hunters Moon Bloodhound','Royal Huntmaster Bloodhound','Royal Livery Bloodhound','Sundown Desperado Bloodhound','Bloody Buccaneer Bloodhound','Dread Navigator Bloodhound','Frosthaven Bloodhound',"Ferals Future Bloodhound",'Lorica Plumata Bloodhound','Bone Chill Bloodhound','Tagged Tracker Bloodhound','Majestic Tracker Bloodhound','Eyes of Horus Bloodhound',"Allfathers Chosen Bloodhound",'Whistling Winter Bloodhound'],
    'Crypto' => ['The Hired Gun Crypto',"Devils Advocate Crypto",'The Masked Dancer Crypto','Rising Phoenix Crypto','Hype Beast Crypto','Machine Language Crypto','Deadly Byte Crypto','Totemic Might Crypto','Hack Frost Crypto','Fuzzy Logic Crypto','Whitelisted Crypto','Seeker of Knowledge Crypto','Winters Grasp Crypto','Midnight Cipher Crypto','Hallowed Spirit Crypto','Awoken Fury Crypto','Nomad Overseer Crypto','Inconspicuous Crypto','Masked Storyteller Crypto','Roaring Guardian Crypto','Elf Made Crypto','Cryptic Conjurer Crypto','Technocrat Crypto','CLASSIFIED Crypto','Darkwatcher Crypto','Serenity Crypto','Hacker crypto'],
    'Valkyrie' => ['Apex Interceptor Valkyrie','Materia Girl Valkyrie','Titan Tested Valkyrie','Military Grade Valkyrie','Golden Opportunity Valkyrie','Azure Blessing Valkyrie','Slingshot Valkyrie','Birthright Valkyrie','Omatsuri Fury Valkyrie','Aerial Evolution Valkyrie','Air Show Valkyrie','Cloud Marauder Valkyrie','Blue Bomber Valkyrie','Air Orchid Valkyrie','Ultra Legend Valkyrie','Higher Learning Valkyrie','Fluorescent Tech Valkyrie','Frozen Blossom Valkyrie','Heartbreaker Valkyrie','Heartbeat Harmonizer Valkyrie','Sky Sentinel Valkyrie','Fae Light Valkyrie','Ascendant Valkyrie'],
    'Seer' => ['Light Show Seer','Plain Sight Seer','Afrofuturism Seer','Tiger Eyes Seer','Out For Blood Seer','Heartthrob Seer','Aces High Seer','The Baron Seer','Envious Attitude Seer','Bladed Wanderer Seer','Celestial Sage Seer','Subculture Seer','Seerside Seer','Ra Talent Seer','Dressed for Luck Seer'],
    'Vantage' => ['Falcon Patrol Vantage','Genesis Effect Vantage','Nocturnal Tactics Vantage','Red Shot Raider Vantage','Ice Cold Vantage','Enchantress Vantage','Cybernetic Survivalist Vantage','Night Cat Vantage','Advanced Tracking Vantage','Graceful Hunt Vantage'],
    'Sparrow' => ['Romeo Sparrow','Malocchio Sparrow','Doro Sparrow','Aperitivo Sparrow'],
    'Gibraltar' => ['Millennium Tusk Gibraltar','Dark Side Gibraltar','Ride or Die Gibraltar','Bunker Buster Gibraltar','Soft Power Gibraltar','Code Red Gibraltar','Call to Arms Gibraltar','Monster Mashed Gibraltar','Redwood Raider Gibraltar','Brudda Bear Gibraltar','Shell-Shocked Gibraltar','Gibraltron Gibraltar','Imperial Defender Gibraltar',"Blazin Hot Gibraltar",'Born in Blood Gibraltar','Golden God Gibraltar','King of the Sea Gibraltar','Lost Dynasty Gibraltar','Blood and Thunder Gibraltar','Gentle Giant Gibraltar','Ring Leader Gibraltar','Booming System Gibraltar','Glorious Combatant Gibraltar','Golden Guardian Gibraltar','Pandamonium Gibraltar','Frozen Magma Gibraltar','Bass Drop Gibraltar','Spirit of Protection Gibraltar','Court Executioner Gibraltar','Fallen Guardian Gibraltar','Bionic Bodyguard Gibraltar','Grave Protector Gibraltar'],
    'Lifeline' => ['Runaway Hit Lifeline','Peak Performer Lifeline','Vital Signs Lifeline','London Calling Lifeline','Organized Anarchy Lifeline','My Wave Lifeline','Lifeline Bling Lifeline','First Responder Lifeline','Judge Jury Executioner Lifeline','From the Ashes Lifeline','Guardian Angel Lifeline','Balance Shift Lifeline','Rejuvination Lifeline','Pirate Queen Lifeline','Breach and Clear Lifeline','Worlds Apart Lifeline','Bad to the Bone Lifeline','Ghost Stalker Lifeline','Hell Raiser Lifeline','Alabaster Titan Lifeline','Mic Check Lifeline','Combat Survivalist Lifeline','Mischief Medic Lifeline','Hyped Healer Lifeline','Healing Huntress Lifeline','Angel of Death Lifeline','Freestyle Lifeline','Shinobi Surgeon Lifeline','Haunt Heal Lifeline','Cruel Medicine Lifeline'],
    'Mirage' => ['The Revenger Mirage','Ghost Machine Mirage','Angel City Hustler Mirage','The Prestige Mirage','Marked Man Mirage','The Dark Artist Mirage','Center Stage Mirage','Captain Bamboozle Mirage','Old Town Mirage','Pit Crew Mirage','The Wisecracker Mirage','Folk Hero Mirage','Man Made Man Mirage',"Fools Gold Mirage",'Seafoam Swindler Mirage','Boogie Down Mirage','Red Carpet Mirage','Swish-buckler Mirage','The Show Stopper Mirage','Chuckles The Barrelman Mirage','Perfect Illusion Mirage','Desert Mirage Mirage','Night Crawler Mirage','Lit Witt Mirage','Red Alert Mirage','Mischief Mage Mirage','Sub-Mirage Mirage','Bad Joke Mirage'],
    'Loba' => ['Gold Standard Loba','Bootlegger Loba','Purple Reign Loba','Off The Record Loba','Crystalline Perfection Loba','Self Reflection Loba','Haute Hoplite Loba','Petty Theft Loba','Rum Runner Loba','Tigress Loba','Arms Dealer Loba','Plumed Explorer Loba','Breaking the Law Loba','Boot Camp Loba','Pastel Pilferer Loba','Supreme Lupine Loba','Elegant Aesthetic Loba','Thrill of the Hunt Loba','Hell Bent Loba','Magenta Militant Loba','Legionnaire Loba','Trouble in Paradise Loba','Sharp Dressed Loba','Lunar Wolf Loba',"Hells Bane Loba",'Lycan Hunter Loba'],
    'Newcastle' => ['Sector 7 Savior Newcastle','Complex Rebirth Newcastle','Green Mosaic Newcastle','Starbound Savior Newcastle','Valiant Defender Newcastle','Heroic Command Newcastle','Mane Event Newcastle','Cosmic Protector Newcastle','Shoreline Savior Newcastle','Chaperone Newcastle'],
    'Conduit' => ['Gilded Radiance Conduit','Long Gone Conduit','No Shade Conduit','Royal Obsidian Conduit','Player One Conduit','Tactical Trendsetter Conduit','Undying Optimism Conduit','Corrupted Guardian Conduit','Lionhearted Conduit','Fluorescent Guardian Conduit'],
    'Caustic' => ['Apex Contagion Caustic','Sixth Sense Caustic','Divine Right Caustic',"Philosophers Stone Caustic",'Blackheart Caustic','Third Emperor Caustic','Synthesis Chamber Caustic','The Trophy Hunter Caustic','Dark Cloud Caustic','Prince of Darkness Caustic','The Last Laugh Caustic','Claustic Caustic','Waste Management Caustic','Necrosis Caustic','Gasbuster Caustic','Bloodthirsty Caustic','Killing Joke Caustic','Sweet Dreams Caustic','Mad King Caustic','Deputy of Death Caustic','Silverback Caustic','Inmate Nox Caustic','Jaeger Caustic','Field Research Caustic','So Serious Caustic','Lion Guard Caustic','Furnace Fury Caustic','Noxious Nobleman Caustic','Toxic Terminator Caustic','Professor Nox Caustic'],
    'Wattson' => ['Kupo Power Wattson','Ace of Sparks Wattson','Fly-by-Wire Wattson','Cyber Security Wattson','Strange Attractor Wattson','Lightning Spirit Wattson','Current Champ Wattson','The Warrior Empress Wattson','Bionic Wonder Wattson','Shocking Stuffer Wattson','Vaporwave Wattson','Silver Age Wattson','Cyber Punked Wattson','Ruby Joules Wattson','Outlands Explorer Wattson','Wired for Speed Wattson','Haute Drop Wattson','Rocket Scientist Wattson','Chaos Conductor Wattson','Deep Current Wattson','Thunder Kitty Wattson','Static Spike Wattson','Kawaii Kitty Wattson','Immovable Energizer Wattson','Solar Static Wattson','System Shock Wattson','Professor Paquette Wattson','Player Two Wattson','Static Trainers Wattson','Missing Lynx Wattson','Porcelian Poppet Wattson','Wicked Voltage Wattson'],
    'Rampart' => ['Premium Finish Rampart','The Devi You Know Rampart','Heritage Pride Rampart','Sari Not Sari Rampart','Death Dealer Rampart','Crafty Kitsune Rampart','Wastelander Rampart','Metallic Dreams Rampart',"Packin Paisley Rampart",'Cleanup Crew Rampart','Rumble Ready Rampart','Sly Fox Rampart','Checkered Frag Rampart','Limit Breaker Rampart','Frozen Carnage Rampart','Crimson Fixer Rampart','Holika Rampart','Soiree Away Rampart','Hellforger Rampart','Sly Sovereign Rampart'],
    'Catalyst' => ['Blood Moon Catalyst','Celestial Protector Catalyst','Legacy of the Ancients Catalyst','Violet Sands Catalyst','Suns Up Catalyst','Technowitch Catalyst','Stellar Swimmer Catalyst','Crimson Goddess Catalyst',"Gorgons Glare Catalyst"],
];
?>

<div class="scx-apex-card">
    <div class="scx-apex-head">
        <span>فرم بازی Apex Legends</span>
        <span class="scx-apex-toggle">+</span>
    </div>

    <div class="scx-apex-content">
        <div class="scx-apex-rank-card scx-medal-card" data-input="apex_rank">
            <div class="scx-card-content">
                <div class="scx-medals scx-apex-ranks">
                    <?php foreach ($apex_ranks as $rank_name):
                        $rank_file = $rank_name . '.png';
                    ?>
                    <div class="scx-medal scx-apex-rank" data-value="<?= esc_attr($rank_name) ?>">
                        <img src="<?= esc_url(SCX_URL . 'assets/apex-ranks/' . rawurlencode($rank_file)) ?>" alt="<?= esc_attr($rank_name) ?>" loading="lazy">
                        <span class="scx-medal-title"><?= esc_html($rank_name) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <input type="hidden" name="apex_rank" value="">
            </div>
        </div>

        <div class="scx-cs2-grid scx-apex-grid">
            <div class="scx-cs2-field">
                <label>Level</label>
                <div class="scx-input">
                    <input type="number" name="apex_level" min="1" max="2000" placeholder="مثال: 750">
                </div>
            </div>
        </div>

        <div class="scx-apex-skin-section">
            <div class="scx-apex-legend-filters">
                <?php foreach ($apex_legend_skins as $legend_name => $legend_skins): ?>
                <button type="button" class="scx-apex-legend-card" data-legend="<?= esc_attr($legend_name) ?>">
                    <span><?= esc_html($legend_name) ?></span>
                </button>
                <?php endforeach; ?>
            </div>

            <div class="scx-apex-skins-grid">
                <?php foreach ($apex_legend_skins as $legend_name => $legend_skins):
                    foreach ($legend_skins as $skin_name):
                        $skin_slug = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $skin_name), '-'));
                ?>
                <label class="scx-apex-skin-card" data-legend="<?= esc_attr($legend_name) ?>">
                    <input type="checkbox" name="apex_skins[]" value="<?= esc_attr($skin_name) ?>">
                    <img src="<?= esc_url(SCX_URL . 'assets/apex-skins/' . $skin_slug . '.jpg') ?>" alt="<?= esc_attr($skin_name) ?>" loading="lazy">
                    <span><?= esc_html($skin_name) ?></span>
                </label>
                <?php endforeach; endforeach; ?>
            </div>
            <input type="hidden" name="apex_selected_legend" value="">
        </div>
    </div>
</div>

</div>

<!-- ================= ACCOUNT SUBMISSION FORM ================= -->

<div class="scx-account-form">

    <div class="scx-form-row">

        <!-- PRICE -->
        <div class="scx-form-field price">
            <label>قیمت</label>
            <div class="scx-input">
                <input type="number" name="account_price" placeholder="مثلا :2,500,000">
            </div>
        </div>

        <!-- MARKET STATUS -->
        <div class="scx-form-field market">
            <label>وضعیت مارکت استیم</label>
            <div class="scx-select scx-form-select">
                <div class="scx-select-trigger">انتخاب</div>
                <div class="scx-select-options">
                    <div class="scx-option" data-value="active">فعال</div>
                    <div class="scx-option" data-value="inactive">غیر فعال</div>
                </div>
                <input type="hidden" name="market_status" value="">
            </div>
        </div>

        <!-- MAIN EMAIL -->
        <div class="scx-form-field email">
            <label>ایمیل اوریجینال</label>
            <div class="scx-select scx-form-select">
                <div class="scx-select-trigger">انتخاب</div>
                <div class="scx-select-options">
                    <div class="scx-option" data-value="yes">بله</div>
                    <div class="scx-option" data-value="no">خیر</div>
                </div>
                <input type="hidden" name="main_email" value="">
            </div>
        </div>

    </div>

    <!-- DESCRIPTION -->
    <div class="scx-form-row full">
        <div class="scx-form-field">
            <label>توضیحات</label>
            <div class="scx-input">
                <textarea name="account_description" rows="4" placeholder="توضیحات کامل آکانت..."></textarea>
            </div>
        </div>
    </div>

    <!-- ACTIONS -->
    <div class="scx-form-actions">

        <div class="scx-upload-wrap">
            <input type="file" id="scx-upload-input" accept="image/*" multiple hidden>
            <button type="button" class="scx-upload-btn">آپلود تصاویر</button>
            <div class="scx-upload-previews"></div>
        </div>

        <button type="button" class="scx-submit-btn">ارسال آکانت</button>

    </div>

</div>

<?php
return ob_get_clean();

});
