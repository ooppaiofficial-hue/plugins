<?php
if (!defined('ABSPATH')) exit;
get_header();

global $post;
$post_id = $post->ID;
$seller_user_id = (int) get_post_field('post_author', $post_id);
$verified_badge = scx_get_verified_badge_html($seller_user_id, ['class' => 'scx-verified-badge-inline']);

/** helper */
function scx_meta($post_id, $key, $fallback = '') {
    $v = get_post_meta($post_id, $key, true);
    return $v !== '' ? $v : $fallback;
}

/* Steam / header */
$steam_avatar = scx_meta($post_id, 'scx_steam_avatar', '');
$steam_name = scx_meta($post_id, 'scx_steam_name', get_the_title($post_id));
$steam_level = scx_meta($post_id, 'scx_steam_level', '');
$steam_profile_url = scx_meta($post_id, 'scx_steam_profile_url', '');

/* Bans */
$communityBan = scx_meta($post_id, 'scx_ban_community', '') === '1';
$tradeBan = scx_meta($post_id, 'scx_ban_trade', '') === '1';
$gameBan = scx_meta($post_id, 'scx_ban_game', '') === '1';
$vacBan = scx_meta($post_id, 'scx_ban_vac', '') === '1';
$anyBan = $communityBan || $tradeBan || $gameBan || $vacBan;

/* Stats */
$games_owned = scx_meta($post_id, 'scx_games_owned', '');
$friends = scx_meta($post_id, 'scx_friends', '');
$account_created = scx_meta($post_id, 'scx_account_created', '');
$region = scx_meta($post_id, 'scx_region', '');

/* Games library (JSON) */
$games_json = scx_meta($post_id, 'scx_games_library', '[]');
$games = json_decode($games_json, true);
if (!is_array($games)) $games = [];

/* Dota */
$dota_medal = scx_meta($post_id, 'scx_dota_medal', '');
$dota_mmr = scx_meta($post_id, 'scx_dota_mmr', '');
$dota_behavior = scx_meta($post_id, 'scx_dota_behavior', '');
$dota_level = scx_meta($post_id, 'scx_dota_level', '');
$dota_shards = scx_meta($post_id, 'scx_dota_shards', '');

/* CS2 */
$cs2_rank = scx_meta($post_id, 'scx_cs2_rank', '');
$cs2_account_type = scx_meta($post_id, 'scx_cs2_account_type', '');
$cs2_prime_status = scx_meta($post_id, 'scx_cs2_prime_status', '');
$cs2_level = scx_meta($post_id, 'scx_cs2_level', '');
$cs2_service_medal = scx_meta($post_id, 'scx_cs2_service_medal', '');

/* Apex */
$apex_rank = scx_meta($post_id, 'scx_apex_rank', '');
$apex_level = scx_meta($post_id, 'scx_apex_level', '');
$apex_selected_legend = scx_meta($post_id, 'scx_apex_selected_legend', '');
$apex_skins_json = scx_meta($post_id, 'scx_apex_skins', '[]');
$apex_skins = json_decode($apex_skins_json, true);
if (!is_array($apex_skins)) $apex_skins = [];
$apex_rank_image = '';
if ($apex_rank !== '') {
    $apex_rank_image = SCX_URL . 'assets/apex-ranks/' . rawurlencode($apex_rank . '.png');
}

/* Market / price / email / description */
$account_price = scx_meta($post_id, 'scx_account_price', '');
$market_status = scx_meta($post_id, 'scx_market_status', '');
$main_email = scx_meta($post_id, 'scx_main_email', '');
$account_description = get_post_field('post_content', $post_id);

/* Gallery images (attachment IDs) */
$gallery = get_post_meta($post_id, 'scx_gallery', true);
if (!is_array($gallery)) $gallery = [];

/* Fallback avatar: post thumbnail */
if (empty($steam_avatar)) {
    $thumb = get_the_post_thumbnail_url($post_id, 'full');
    if ($thumb) $steam_avatar = $thumb;
}

/* medals list (used for building selected-medal filename) */
$medals = [
    'Herald'    => [1,2,3,4,5],
    'Guardian'  => [1,2,3,4,5],
    'Crusader'  => [1,2,3,4,5],
    'Archon'    => [1,2,3,4,5],
    'Legend'    => [1,2,3,4,5],
    'Ancient'   => [1,2,3,4,5],
    'Divine'    => [1,2,3,4,5],
    'Immortal'  => [1],
    'Immortal Top'  => [100, 10],
];

/* parse selected medal into name & star if present */
$selected_medal_name = '';
$selected_medal_star = '';
if (!empty($dota_medal) && strpos($dota_medal, '-') !== false) {
    list($selected_medal_name, $selected_medal_star) = explode('-', $dota_medal, 2);
}
$selected_medal_img = '';
if ($selected_medal_name && $selected_medal_star) {
    $medal_slug = lcfirst(str_replace(' ', '-', $selected_medal_name));
    $selected_medal_img = SCX_URL . "assets/medals/" . $medal_slug . "-" . intval($selected_medal_star) . ".png";
}

$cs2_rank_tier_class = 'tier-default';
if (!empty($cs2_rank)) {
    if (stripos($cs2_rank, 'Silver') === 0) {
        $cs2_rank_tier_class = 'tier-silver';
    } elseif (stripos($cs2_rank, 'Gold Nova') === 0) {
        $cs2_rank_tier_class = 'tier-gold';
    } elseif (stripos($cs2_rank, 'Master Guardian') === 0 || stripos($cs2_rank, 'Distinguished Master Guardian') === 0) {
        $cs2_rank_tier_class = 'tier-guardian';
    } elseif (stripos($cs2_rank, 'Legendary Eagle') === 0) {
        $cs2_rank_tier_class = 'tier-eagle';
    } elseif (stripos($cs2_rank, 'Supreme') === 0) {
        $cs2_rank_tier_class = 'tier-supreme';
    } elseif (stripos($cs2_rank, 'Global') === 0) {
        $cs2_rank_tier_class = 'tier-global';
    }
}

$cs2_account_type_labels = [
    'main_account' => 'اکانت شخصی (Main Account)',
    'smurf' => 'اسمورف (Smurf)',
    'leveled_up' => 'لول‌اپ شده',
    'fresh' => 'تازه ساخته شده',
    'skins_only' => 'فقط برای اسکین',
    'legacy' => 'اکانت قدیمی (Legacy)',
];
$cs2_prime_status_labels = [
    'active_prime' => 'دارد (Active Prime)',
    'no_prime' => 'ندارد',
];
?>
<div class="scx-wrapper">


	<?php if (!empty($gallery)): ?>
<div class="scx-pro-gallery">

    <!-- MAIN SLIDER -->
    <div class="scx-pro-main">

        <?php foreach ($gallery as $i => $att_id):
            $full = wp_get_attachment_image_url($att_id, 'full');
            $large = wp_get_attachment_image_url($att_id, 'large');
            if (!$full) continue;
        ?>
        <div class="scx-pro-slide <?= $i===0 ? 'active':'' ?>">
            <img 
                src="<?= esc_url($large ?: $full) ?>"
                data-full="<?= esc_url($full) ?>"
                loading="lazy"
            >
        </div>
        <?php endforeach; ?>

        <button class="scx-pro-prev">‹</button>
        <button class="scx-pro-next">›</button>

    </div>

    <!-- THUMBNAILS -->
    <div class="scx-pro-thumbs">
        <?php foreach ($gallery as $i => $att_id):
            $thumb = wp_get_attachment_image_url($att_id, 'thumbnail');
            if (!$thumb) continue;
        ?>
        <img 
            src="<?= esc_url($thumb) ?>"
            class="scx-thumb <?= $i===0?'active':'' ?>"
            data-index="<?= $i ?>"
        >
        <?php endforeach; ?>
    </div>

</div>

<!-- LIGHTBOX -->
<div class="scx-pro-lightbox">
    <span class="scx-lightbox-close">×</span>
    <img class="scx-lightbox-img">
</div>

<?php endif; ?>

    <!-- HEADER -->
    <div class="scx-header-card">

        <div class="scx-avatar-wrap">
            <img src="<?= esc_url($steam_avatar) ?>" alt="<?= esc_attr($steam_name) ?>">
        </div>

        <div class="scx-header-info">

            <h2><?= esc_html($steam_name) ?> <?= $verified_badge // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></h2>

            <?php if ($steam_profile_url): ?>
                <a href="<?= esc_url($steam_profile_url) ?>" target="_blank" class="scx-profile-link">
                    Steam Profile
                </a>
            <?php endif; ?>

            <div class="scx-badges">
                <span class="scx-badge pro">PRO</span>
                <span class="scx-steam-level">Lv <?= intval($steam_level) ?></span>
            </div>

        </div>

    </div>

    <!-- STATS -->
    <div class="scx-stats-grid">

        <!-- BAN MASTER BOX -->
        <div class="scx-ban-box <?= $anyBan ? 'banned' : 'clean' ?>">

            <div class="scx-ban-status">
                STATUS : <?= $anyBan ? 'BANNED' : 'CLEAN' ?>
            </div>

            <div class="scx-ban-grid">

                <div class="scx-ban-item <?= $communityBan ? 'bad' : 'good' ?>">
                    Community Ban
                </div>

                <div class="scx-ban-item <?= $tradeBan ? 'bad' : 'good' ?>">
                    Trade / Market Ban
                </div>

                <div class="scx-ban-item <?= $gameBan ? 'bad' : 'good' ?>">
                    Game Ban
                </div>

                <div class="scx-ban-item <?= $vacBan ? 'bad' : 'good' ?>">
                    VAC Ban
                </div>

            </div>

        </div>

        <!-- RIGHT STATS -->
        <div class="scx-stat blue">
            <span>Games Owned</span>
            <strong><?= esc_html($games_owned !== '' ? $games_owned : count($games)) ?></strong>
        </div>

        <div class="scx-stat purple">
            <span>Friends</span>
            <strong><?= esc_html($friends) ?></strong>
        </div>

        <div class="scx-stat teal">
            <span>Account Created</span>
            <strong><?= esc_html($account_created) ?></strong>
        </div>

        <div class="scx-stat gold">
            <span>Region</span>
            <strong><?= esc_html($region) ?></strong>
        </div>

    </div>

   
    <!-- GAMES -->
    <?php
    $games_total_usd = 0;
    foreach ($games as $total_game) {
        $total_price_text = $total_game['price'] ?? ($total_game['price_overview']['final_formatted'] ?? '');
        if (!$total_price_text || stripos($total_price_text, 'free') !== false) {
            continue;
        }

        if (preg_match('/\$\s*([\d\.,]+)/', $total_price_text, $m)) {
            $amount = floatval(str_replace(',', '', $m[1]));
            $games_total_usd += $amount;
        }
    }
    ?>
    <h3 class="scx-section-title">
        <span>Game Library</span>
        <span class="scx-total-price">
            <span class="scx-total-price-value">Total: $<?= number_format($games_total_usd, 2) ?></span>
            <span class="scx-total-price-tooltip">جمع قیمت بازی های آکانت استیم</span>
        </span>
    </h3>

    <div class="scx-games-grid">
        <?php foreach ($games as $game):
            // try to get numeric hours
            $playtime_hours = 0;
            if (!empty($game['hours_raw'])) {
                $playtime_hours = intval($game['hours_raw']);
            } elseif (!empty($game['hours'])) {
                preg_match_all('/\d+/', $game['hours'], $m);
                $playtime_hours = intval($m[0][0] ?? 0);
            } elseif (!empty($game['playtime_forever'])) {
                $playtime_hours = floor(intval($game['playtime_forever']) / 60);
            }
            $appid = $game['appid'] ?? 0;
            $img = !empty($game['image']) ? $game['image'] : ($appid ? "https://cdn.cloudflare.steamstatic.com/steam/apps/{$appid}/header.jpg" : '');
            $price_text = $game['price'] ?? ($game['price_overview']['final_formatted'] ?? '');
            $is_free = stripos($price_text, 'free') !== false;
        ?>
            <div class="scx-game-card">

                <?php if ($img): ?>
                    <img src="<?= esc_url($img) ?>" alt="<?= esc_attr($game['name'] ?? '') ?>">
                <?php endif; ?>

                <div class="scx-game-info">
                    <div class="scx-game-title"><?= esc_html($game['name'] ?? '') ?></div>
                    <div class="scx-game-meta">
                        <span class="scx-game-hours"><?= esc_html($playtime_hours) ?> ساعت </span>
                        <?php if ($is_free): ?>
                            <span class="scx-game-free">Free</span>
                        <?php elseif (!empty($price_text)): ?>
                            <span class="scx-game-price"><?= esc_html($price_text) ?></span>
                        <?php else: ?>
                            <span class="scx-game-price">Paid</span>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        <?php endforeach; ?>
    </div>



	<?php
$has_dota_data =
    !empty($dota_medal) ||
    $dota_mmr !== '' ||
    $dota_behavior !== '' ||
    $dota_level !== '' ||
    $dota_shards !== '';
?>

    <?php if ($has_dota_data): ?>
<!-- ================= DOTA 2 PROFESSIONAL CARD ================= -->
<div class="scx-dota-card">

        <div class="scx-dota-head">
            <span> اطلاعات بازی Dota 2</span>
            <span class="scx-dota-toggle">+</span>
        </div>

        <div class="scx-dota-content" style="display:block;">

            <!-- Show only the selected medal (single) -->
            <div class="scx-medal-card">
                <div class="scx-card-content">
                    <div class="scx-medals">
                        <?php if ($selected_medal_name && $selected_medal_star && $selected_medal_img): 
                            $medal_class = strtolower(str_replace(' ', '-', $selected_medal_name));
                        ?>
                            <div class="scx-medal <?= esc_attr($medal_class) ?> active">
                                <img src="<?= esc_url($selected_medal_img) ?>" alt="<?= esc_attr($dota_medal) ?>">
                                <span class="scx-medal-title"><?= esc_html($selected_medal_name . ' ' . $selected_medal_star) ?></span>
                            </div>
                        <?php else: ?>
                            <div class="scx-medal" style="opacity:.6">
                                <img src="<?= esc_url(SCX_URL . 'assets/medals/herald-1.png') ?>" alt="No medal">
                                <span class="scx-medal-title">No Medal</span>
                            </div>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" name="dota_medal" value="<?= esc_attr($dota_medal) ?>">
                </div>
            </div>

            <div class="scx-dota-grid">

 <!-- MMR -->
<div class="scx-dota-field blue">
    <label>MMR</label>
    <div class="scx-output">
        <?= esc_html($dota_mmr !== '' ? number_format($dota_mmr) : '--') ?>
    </div>
</div>

<!-- BEHAVIOR -->
<div class="scx-dota-field teal">
    <label>Behavior Score</label>
    <div class="scx-output">
        <?= esc_html($dota_behavior !== '' ? number_format($dota_behavior) : '--') ?>
    </div>
</div>

<!-- LEVEL -->
<div class="scx-dota-field gold">
    <label>Dota Level</label>
    <div class="scx-output">
        <?= esc_html($dota_level !== '' ? number_format($dota_level) : '--') ?>
    </div>
</div>

<!-- SHARDS -->
<div class="scx-dota-field shards">
    <label>Shards</label>
    <div class="scx-output">
        <?= esc_html($dota_shards !== '' ? number_format($dota_shards) : '--') ?>
    </div>
</div>

</div> <!-- scx-dota-grid -->
</div> <!-- scx-dota-content -->
</div> <!-- scx-dota-card -->
<?php endif; ?>

<?php
$has_cs2_data =
    !empty($cs2_rank) ||
    !empty($cs2_account_type) ||
    !empty($cs2_prime_status) ||
    $cs2_level !== '' ||
    !empty($cs2_service_medal);
?>

<?php if ($has_cs2_data): ?>
<div class="scx-cs2-card scx-cs2-single-card">
    <div class="scx-cs2-head">
        <span>اطلاعات بازی Cs2</span>
        <span class="scx-cs2-toggle">+</span>
    </div>

    <div class="scx-cs2-content" style="display:block;">
        <div class="scx-cs2-rank-card scx-medal-card">
            <div class="scx-card-content">
                <div class="scx-medals scx-cs2-ranks scx-cs2-rank-single">
                    <?php if (!empty($cs2_rank)): ?>
                        <div class="scx-medal scx-cs2-rank active <?= esc_attr($cs2_rank_tier_class) ?>">
                            <span class="scx-medal-title"><?= esc_html($cs2_rank) ?></span>
                        </div>
                    <?php else: ?>
                        <div class="scx-medal scx-cs2-rank tier-default" style="opacity:.6">
                            <span class="scx-medal-title">No Rank</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="scx-cs2-grid scx-cs2-grid-single">
            <div class="scx-cs2-field">
                <label>نوع آکانت</label>
                <div class="scx-output"><?= esc_html($cs2_account_type_labels[$cs2_account_type] ?? '--') ?></div>
            </div>

            <div class="scx-cs2-field">
                <label>وضعیت پرایم</label>
                <div class="scx-output"><?= esc_html($cs2_prime_status_labels[$cs2_prime_status] ?? '--') ?></div>
            </div>

            <div class="scx-cs2-field">
                <label>لول بازی</label>
                <div class="scx-output"><?= esc_html($cs2_level !== '' ? number_format((int) $cs2_level) : '--') ?></div>
            </div>

            <div class="scx-cs2-field scx-cs2-field-full">
                <label>Service Medal</label>
                <div class="scx-output"><?= esc_html($cs2_service_medal !== '' ? $cs2_service_medal : '--') ?></div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<?php
$has_apex_data =
    !empty($apex_rank) ||
    $apex_level !== '' ||
    !empty($apex_skins);
?>

<?php if ($has_apex_data): ?>
<div class="scx-apex-card scx-apex-single-card">
    <div class="scx-apex-head">
        <span>اطلاعات بازی Apex Legends</span>
        <span class="scx-apex-toggle">+</span>
    </div>

    <div class="scx-apex-content" style="display:block;">
        <div class="scx-apex-single-topline">
            <div class="scx-apex-single-rank">
                <?php if (!empty($apex_rank_image)): ?>
                    <img src="<?= esc_url($apex_rank_image) ?>" alt="<?= esc_attr($apex_rank) ?>" loading="lazy">
                <?php endif; ?>
                <div>
                    <label>Rank</label>
                    <div class="scx-output"><?= esc_html($apex_rank !== '' ? $apex_rank : '--') ?></div>
                </div>
            </div>

            <div class="scx-apex-single-level">
                <label>Level</label>
                <div class="scx-output"><?= esc_html($apex_level !== '' ? number_format((int) $apex_level) : '--') ?></div>
            </div>
        </div>

        <?php if (!empty($apex_skins)): ?>
        <div class="scx-apex-skins-grid">
            <?php foreach ($apex_skins as $skin_name):
                $skin_slug = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $skin_name), '-'));
                $skin_primary = SCX_URL . 'assets/apex-skins/' . $skin_slug . '.jpg';
                $legend_name = trim(substr($skin_name, strrpos($skin_name, ' ') + 1));
                $skin_legacy = SCX_URL . 'assets/apex-skins/' . rawurlencode($legend_name) . '/' . rawurlencode($skin_name) . '.jpg';
            ?>
                <div class="scx-apex-skin-card selected scx-apex-single-skin-card">
                    <img src="<?= esc_url($skin_primary) ?>" data-fallback="<?= esc_url($skin_legacy) ?>" alt="<?= esc_attr($skin_name) ?>" loading="lazy" onerror="if(!this.dataset.fallbackUsed){this.dataset.fallbackUsed='1';this.src=this.dataset.fallback;}">
                    <span><?= esc_html($skin_name) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>


    </div>

    <!-- ================= ACCOUNT DETAILS (single page modern card) ================= -->
    <?php
    $price_number = floatval(str_replace([',', ' '], '', (string) $account_price));
    $price_display = $account_price !== '' ? number_format($price_number) . ' تومان' : 'نامشخص';
    $market_label = $market_status === 'active' ? 'فعال' : ($market_status === 'inactive' ? 'غیرفعال' : 'نامشخص');
    $email_label = $main_email === 'yes' ? 'دارد' : ($main_email === 'no' ? 'ندارد' : 'نامشخص');
    ?>
    <section class="scx-single-sale-details">
        <div class="scx-single-sale-head">
        </div>

        <div class="scx-single-kpi-grid">
            <article class="scx-single-kpi scx-single-kpi-price">
                <span class="scx-kpi-icon" aria-hidden="true">💰</span>
                <div>
                    <div class="scx-kpi-label">قیمت اکانت</div>
                    <div class="scx-kpi-value"><?= esc_html($price_display) ?></div>
                </div>
            </article>

            <article class="scx-single-kpi">
                <span class="scx-kpi-icon" aria-hidden="true">🛒</span>
                <div>
                    <div class="scx-kpi-label">وضعیت مارکت استیم</div>
                    <div class="scx-kpi-value"><?= esc_html($market_label) ?></div>
                </div>
            </article>

            <article class="scx-single-kpi">
                <span class="scx-kpi-icon" aria-hidden="true">📧</span>
                <div>
                    <div class="scx-kpi-label">ایمیل اوریجینال</div>
                    <div class="scx-kpi-value"><?= esc_html($email_label) ?></div>
                </div>
            </article>
        </div>

        <div class="scx-single-description-box">
            <h4>توضیحات فروشنده</h4>
            <div class="scx-single-description-text">
                <?php if (trim((string) $account_description) !== ''): ?>
                    <?= wp_kses_post(wpautop($account_description)) ?>
                <?php else: ?>
                    <p>توضیحاتی برای این آگهی ثبت نشده است.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <style>
        .scx-single-sale-details{margin-top:34px;padding:24px;border-radius:20px;background:radial-gradient(circle at top right,#172554,#0f172a 60%);border:1px solid rgba(148,163,184,.28);box-shadow:0 16px 35px rgba(2,6,23,.45)}
        .scx-single-sale-head h3{margin:0;font-size:22px;color:#fff}
        .scx-single-sale-head p{margin:8px 0 0;color:#cbd5e1;font-size:14px}
        .scx-single-kpi-grid{margin-top:18px;display:grid;gap:12px;grid-template-columns:repeat(3,minmax(0,1fr))}
        .scx-single-kpi{display:flex;align-items:center;gap:12px;background:rgba(15,23,42,.75);border:1px solid rgba(148,163,184,.22);border-radius:14px;padding:14px}
        .scx-single-kpi-price{background:linear-gradient(135deg,#22c55e,#0ea5e9);border:none}
        .scx-kpi-icon{font-size:20px}
        .scx-kpi-label{font-size:12px;color:#cbd5e1}
        .scx-single-kpi-price .scx-kpi-label,.scx-single-kpi-price .scx-kpi-value{color:#fff}
        .scx-kpi-value{font-size:18px;font-weight:700;color:#f8fafc}
        .scx-single-description-box{margin-top:18px;padding:16px;border-radius:14px;background:rgba(15,23,42,.7);border:1px solid rgba(148,163,184,.22)}
        .scx-single-description-box h4{margin:0 0 10px;color:#e2e8f0;font-size:17px}
        .scx-single-description-text{color:#cbd5e1;line-height:1.9}
        .scx-single-description-text p{margin:0 0 10px}
        .scx-single-description-text p:last-child{margin-bottom:0}
        @media (max-width:900px){.scx-single-kpi-grid{grid-template-columns:1fr}}
    </style>

</div>
<?php get_footer(); ?>
