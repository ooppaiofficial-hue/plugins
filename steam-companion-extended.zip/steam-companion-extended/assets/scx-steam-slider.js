(function () {
  function initSlider(root) {
    var track = root.querySelector('[data-scx-track]');
    var prev = root.querySelector('[data-scx-prev]');
    var next = root.querySelector('[data-scx-next]');

    if (!track || !prev || !next) return;

    var slideBy = function (direction) {
      var amount = track.clientWidth;
      track.scrollBy({ left: amount * direction, behavior: 'smooth' });
    };

    prev.addEventListener('click', function () { slideBy(-1); });
    next.addEventListener('click', function () { slideBy(1); });

    var autoplay = setInterval(function () {
      var isEnd = Math.ceil(track.scrollLeft + track.clientWidth) >= track.scrollWidth;
      if (isEnd) {
        track.scrollTo({ left: 0, behavior: 'smooth' });
      } else {
        slideBy(1);
      }
    }, 5000);

    root.addEventListener('mouseenter', function () {
      clearInterval(autoplay);
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-scx-slider]').forEach(function (slider) {
      initSlider(slider.closest('.scx-steam-slider-section') || slider);
    });
  });
})();
