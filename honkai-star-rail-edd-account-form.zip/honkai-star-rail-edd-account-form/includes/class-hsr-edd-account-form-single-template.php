<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class HSR_EDD_Account_Form_Single_Template {
	const TEMPLATE_FILE = 'templates/single-hsr-account.php';

	/**
	 * Register single template hooks.
	 */
	public function hooks() {
		add_filter( 'template_include', array( $this, 'load_single_download_template' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * @param string $template Current selected template.
	 * @return string
	 */
	public function load_single_download_template( $template ) {
		if ( ! $this->is_target_single_download() ) {
			return $template;
		}

		$custom_template = HSR_EDD_FORM_DIR . self::TEMPLATE_FILE;
		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}

		return $template;
	}

	/**
	 * Register/enqueue assets for the single product template.
	 */
	public function enqueue_assets() {
		wp_register_style( 'hsr-account-single-style', HSR_EDD_FORM_URL . 'assets/css/single-account.css', array(), HSR_EDD_FORM_VERSION );
		wp_register_script( 'hsr-account-single-script', HSR_EDD_FORM_URL . 'assets/js/single-account.js', array(), HSR_EDD_FORM_VERSION, true );

		if ( $this->is_target_single_download() ) {
			wp_enqueue_style( 'hsr-account-single-style' );
			wp_enqueue_script( 'hsr-account-single-script' );

			$hsr_single_seo_css = <<<'CSS'
.hsr-single-account__seo-title{margin:-12px 0 18px;font-size:16px;line-height:1.8;color:var(--hsr-text-dim,#9fb2dd);font-weight:700;}
.hsr-single-account__keywords{margin:0;padding:0;list-style:none;display:flex;flex-wrap:wrap;gap:8px;}
.hsr-single-account__keywords li{padding:6px 10px;border-radius:999px;background:rgba(79,209,255,.12);border:1px solid rgba(79,209,255,.35);font-size:12px;color:#dce9ff;}
.hsr-single-account__keywords li a{color:inherit;text-decoration:none;}
.hsr-single-account__keywords li a:hover,.hsr-single-account__keywords li a:focus{text-decoration:underline;}
CSS;

			wp_add_inline_style( 'hsr-account-single-style', $hsr_single_seo_css );
		}
	}

	/**
	 * @return bool
	 */
	private function is_target_single_download() {
		if ( ! is_singular( 'download' ) ) {
			return false;
		}

		if ( ! taxonomy_exists( HSR_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_TAXONOMY ) ) {
			return false;
		}

		return has_term(
			HSR_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_SLUG,
			HSR_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_TAXONOMY,
			get_queried_object_id()
		);
	}
}
